# Third-party notices and corresponding source

## Chess Vision

Copyright 2026. Licensed under GNU GPL version 3 only. See LICENSE.

## Stockfish.js 17.1.0

Copyright Stockfish contributors, Nathan Rugg, Chess.com LLC and other contributors listed in upstream AUTHORS.

- Distribution: <https://registry.npmjs.org/stockfish/-/stockfish-17.1.0.tgz>
- Corresponding source and build instructions: <https://github.com/nmrugg/stockfish.js/tree/v17.1.0> (commit `f9512ef9aff391026813a56855dd086cb72a2d58`)
- Repository: <https://github.com/nmrugg/stockfish.js>
- Stockfish core: <https://github.com/official-stockfish/Stockfish>
- License: GPL version 3; upstream Copying.txt is included in the built engine folder and this project's LICENSE.

The build copies `src/stockfish-17.1-lite-single-03e3232.js` and its matching `.wasm` from the pinned npm package, renaming them to `stockfish.js` and `stockfish.wasm`. It also copies the package's `stockfish-17.1-asm-341ff22.js` to `stockfish-asm.js` as a compatibility backend. Engine code is unmodified. The package integrity is recorded in package-lock.json. When redistributing binaries, comply with GPL corresponding-source requirements; these links identify upstream, and are not a substitute for your own source-delivery obligations.

Version 1.2.0 additionally bundles `stockfish-17.1-single-a496a04.js` and all six matching `-part-N.wasm` files under `engine/full/`, renamed consistently to `stockfish.js` and `stockfish-part-N.wasm`. This is the full NNUE single-thread variant used by Magnus mode; its engine code and network contents are unmodified and share the same pinned corresponding-source archive.

The deliverables also include `stockfish-17.1.0-upstream-source.zip`, the complete unmodified upstream archive for that exact commit, including C++ source, build scripts, networks, and upstream artifacts.

## chess.js 1.4.0

Copyright (c) 2025, Jeff Hlywa (jhlywa@gmail.com). BSD-2-Clause license. See THIRD-PARTY-LICENSES.txt for the license text copied from the installed package.

## Piece artwork

No Chess.com artwork is bundled or redistributed. The optional visual fallback reads piece images from the website's existing public artwork CDN at runtime, subject to CORS. The extension's interface uses system fonts and text chess symbols.

## Witty Alien derived data and model
The local repertoire and fitted preference weights derive from public Witty_Alien games retrieved through the Chess.com Published Data API. MODEL-CARD.md identifies sources, methods and limits. Original PGNs, avatars and player artwork are not bundled. Player names do not imply endorsement. Other named study themes are coaching prompts rather than trained replicas.
