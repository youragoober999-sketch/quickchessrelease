/* © 2026 fwgavvin — QuickChess. All rights reserved. Unauthorized redistribution or resale prohibited. Contact @fwgavvin on TikTok. */
(() => {
  // node_modules/chess.js/dist/esm/chess.js
  function rootNode(comment) {
    return comment !== null ? { comment, variations: [] } : { variations: [] };
  }
  function node(move, suffix, nag, comment, variations) {
    const node2 = { move, variations };
    if (suffix) {
      node2.suffix = suffix;
    }
    if (nag) {
      node2.nag = nag;
    }
    if (comment !== null) {
      node2.comment = comment;
    }
    return node2;
  }
  function lineToTree(...nodes) {
    const [root, ...rest] = nodes;
    let parent = root;
    for (const child of rest) {
      if (child !== null) {
        parent.variations = [child, ...child.variations];
        child.variations = [];
        parent = child;
      }
    }
    return root;
  }
  function pgn(headers, game) {
    if (game.marker && game.marker.comment) {
      let node2 = game.root;
      while (true) {
        const next = node2.variations[0];
        if (!next) {
          node2.comment = game.marker.comment;
          break;
        }
        node2 = next;
      }
    }
    return {
      headers,
      root: game.root,
      result: (game.marker && game.marker.result) ?? void 0
    };
  }
  function peg$subclass(child, parent) {
    function C() {
      this.constructor = child;
    }
    C.prototype = parent.prototype;
    child.prototype = new C();
  }
  function peg$SyntaxError(message, expected, found, location2) {
    var self = Error.call(this, message);
    if (Object.setPrototypeOf) {
      Object.setPrototypeOf(self, peg$SyntaxError.prototype);
    }
    self.expected = expected;
    self.found = found;
    self.location = location2;
    self.name = "SyntaxError";
    return self;
  }
  peg$subclass(peg$SyntaxError, Error);
  function peg$padEnd(str, targetLength, padString) {
    padString = padString || " ";
    if (str.length > targetLength) {
      return str;
    }
    targetLength -= str.length;
    padString += padString.repeat(targetLength);
    return str + padString.slice(0, targetLength);
  }
  peg$SyntaxError.prototype.format = function(sources) {
    var str = "Error: " + this.message;
    if (this.location) {
      var src = null;
      var k;
      for (k = 0; k < sources.length; k++) {
        if (sources[k].source === this.location.source) {
          src = sources[k].text.split(/\r\n|\n|\r/g);
          break;
        }
      }
      var s = this.location.start;
      var offset_s = this.location.source && typeof this.location.source.offset === "function" ? this.location.source.offset(s) : s;
      var loc = this.location.source + ":" + offset_s.line + ":" + offset_s.column;
      if (src) {
        var e = this.location.end;
        var filler = peg$padEnd("", offset_s.line.toString().length, " ");
        var line = src[s.line - 1];
        var last = s.line === e.line ? e.column : line.length + 1;
        var hatLen = last - s.column || 1;
        str += "\n --> " + loc + "\n" + filler + " |\n" + offset_s.line + " | " + line + "\n" + filler + " | " + peg$padEnd("", s.column - 1, " ") + peg$padEnd("", hatLen, "^");
      } else {
        str += "\n at " + loc;
      }
    }
    return str;
  };
  peg$SyntaxError.buildMessage = function(expected, found) {
    var DESCRIBE_EXPECTATION_FNS = {
      literal: function(expectation) {
        return '"' + literalEscape(expectation.text) + '"';
      },
      class: function(expectation) {
        var escapedParts = expectation.parts.map(function(part) {
          return Array.isArray(part) ? classEscape(part[0]) + "-" + classEscape(part[1]) : classEscape(part);
        });
        return "[" + (expectation.inverted ? "^" : "") + escapedParts.join("") + "]";
      },
      any: function() {
        return "any character";
      },
      end: function() {
        return "end of input";
      },
      other: function(expectation) {
        return expectation.description;
      }
    };
    function hex(ch) {
      return ch.charCodeAt(0).toString(16).toUpperCase();
    }
    function literalEscape(s) {
      return s.replace(/\\/g, "\\\\").replace(/"/g, '\\"').replace(/\0/g, "\\0").replace(/\t/g, "\\t").replace(/\n/g, "\\n").replace(/\r/g, "\\r").replace(/[\x00-\x0F]/g, function(ch) {
        return "\\x0" + hex(ch);
      }).replace(/[\x10-\x1F\x7F-\x9F]/g, function(ch) {
        return "\\x" + hex(ch);
      });
    }
    function classEscape(s) {
      return s.replace(/\\/g, "\\\\").replace(/\]/g, "\\]").replace(/\^/g, "\\^").replace(/-/g, "\\-").replace(/\0/g, "\\0").replace(/\t/g, "\\t").replace(/\n/g, "\\n").replace(/\r/g, "\\r").replace(/[\x00-\x0F]/g, function(ch) {
        return "\\x0" + hex(ch);
      }).replace(/[\x10-\x1F\x7F-\x9F]/g, function(ch) {
        return "\\x" + hex(ch);
      });
    }
    function describeExpectation(expectation) {
      return DESCRIBE_EXPECTATION_FNS[expectation.type](expectation);
    }
    function describeExpected(expected2) {
      var descriptions = expected2.map(describeExpectation);
      var i, j;
      descriptions.sort();
      if (descriptions.length > 0) {
        for (i = 1, j = 1; i < descriptions.length; i++) {
          if (descriptions[i - 1] !== descriptions[i]) {
            descriptions[j] = descriptions[i];
            j++;
          }
        }
        descriptions.length = j;
      }
      switch (descriptions.length) {
        case 1:
          return descriptions[0];
        case 2:
          return descriptions[0] + " or " + descriptions[1];
        default:
          return descriptions.slice(0, -1).join(", ") + ", or " + descriptions[descriptions.length - 1];
      }
    }
    function describeFound(found2) {
      return found2 ? '"' + literalEscape(found2) + '"' : "end of input";
    }
    return "Expected " + describeExpected(expected) + " but " + describeFound(found) + " found.";
  };
  function peg$parse(input, options) {
    options = options !== void 0 ? options : {};
    var peg$FAILED = {};
    var peg$source = options.grammarSource;
    var peg$startRuleFunctions = { pgn: peg$parsepgn };
    var peg$startRuleFunction = peg$parsepgn;
    var peg$c0 = "[";
    var peg$c1 = '"';
    var peg$c2 = "]";
    var peg$c3 = ".";
    var peg$c4 = "O-O-O";
    var peg$c5 = "O-O";
    var peg$c6 = "0-0-0";
    var peg$c7 = "0-0";
    var peg$c8 = "$";
    var peg$c9 = "{";
    var peg$c10 = "}";
    var peg$c11 = ";";
    var peg$c12 = "(";
    var peg$c13 = ")";
    var peg$c14 = "1-0";
    var peg$c15 = "0-1";
    var peg$c16 = "1/2-1/2";
    var peg$c17 = "*";
    var peg$r0 = /^[a-zA-Z]/;
    var peg$r1 = /^[^"]/;
    var peg$r2 = /^[0-9]/;
    var peg$r3 = /^[.]/;
    var peg$r4 = /^[a-zA-Z1-8\-=]/;
    var peg$r5 = /^[+#]/;
    var peg$r6 = /^[!?]/;
    var peg$r7 = /^[^}]/;
    var peg$r8 = /^[^\r\n]/;
    var peg$r9 = /^[ \t\r\n]/;
    var peg$e0 = peg$otherExpectation("tag pair");
    var peg$e1 = peg$literalExpectation("[", false);
    var peg$e2 = peg$literalExpectation('"', false);
    var peg$e3 = peg$literalExpectation("]", false);
    var peg$e4 = peg$otherExpectation("tag name");
    var peg$e5 = peg$classExpectation([["a", "z"], ["A", "Z"]], false, false);
    var peg$e6 = peg$otherExpectation("tag value");
    var peg$e7 = peg$classExpectation(['"'], true, false);
    var peg$e8 = peg$otherExpectation("move number");
    var peg$e9 = peg$classExpectation([["0", "9"]], false, false);
    var peg$e10 = peg$literalExpectation(".", false);
    var peg$e11 = peg$classExpectation(["."], false, false);
    var peg$e12 = peg$otherExpectation("standard algebraic notation");
    var peg$e13 = peg$literalExpectation("O-O-O", false);
    var peg$e14 = peg$literalExpectation("O-O", false);
    var peg$e15 = peg$literalExpectation("0-0-0", false);
    var peg$e16 = peg$literalExpectation("0-0", false);
    var peg$e17 = peg$classExpectation([["a", "z"], ["A", "Z"], ["1", "8"], "-", "="], false, false);
    var peg$e18 = peg$classExpectation(["+", "#"], false, false);
    var peg$e19 = peg$otherExpectation("suffix annotation");
    var peg$e20 = peg$classExpectation(["!", "?"], false, false);
    var peg$e21 = peg$otherExpectation("NAG");
    var peg$e22 = peg$literalExpectation("$", false);
    var peg$e23 = peg$otherExpectation("brace comment");
    var peg$e24 = peg$literalExpectation("{", false);
    var peg$e25 = peg$classExpectation(["}"], true, false);
    var peg$e26 = peg$literalExpectation("}", false);
    var peg$e27 = peg$otherExpectation("rest of line comment");
    var peg$e28 = peg$literalExpectation(";", false);
    var peg$e29 = peg$classExpectation(["\r", "\n"], true, false);
    var peg$e30 = peg$otherExpectation("variation");
    var peg$e31 = peg$literalExpectation("(", false);
    var peg$e32 = peg$literalExpectation(")", false);
    var peg$e33 = peg$otherExpectation("game termination marker");
    var peg$e34 = peg$literalExpectation("1-0", false);
    var peg$e35 = peg$literalExpectation("0-1", false);
    var peg$e36 = peg$literalExpectation("1/2-1/2", false);
    var peg$e37 = peg$literalExpectation("*", false);
    var peg$e38 = peg$otherExpectation("whitespace");
    var peg$e39 = peg$classExpectation([" ", "	", "\r", "\n"], false, false);
    var peg$f0 = function(headers, game) {
      return pgn(headers, game);
    };
    var peg$f1 = function(tagPairs) {
      return Object.fromEntries(tagPairs);
    };
    var peg$f2 = function(tagName, tagValue) {
      return [tagName, tagValue];
    };
    var peg$f3 = function(root, marker) {
      return { root, marker };
    };
    var peg$f4 = function(comment, moves) {
      return lineToTree(rootNode(comment), ...moves.flat());
    };
    var peg$f5 = function(san, suffix, nag, comment, variations) {
      return node(san, suffix, nag, comment, variations);
    };
    var peg$f6 = function(nag) {
      return nag;
    };
    var peg$f7 = function(comment) {
      return comment.replace(/[\r\n]+/g, " ");
    };
    var peg$f8 = function(comment) {
      return comment.trim();
    };
    var peg$f9 = function(line) {
      return line;
    };
    var peg$f10 = function(result, comment) {
      return { result, comment };
    };
    var peg$currPos = options.peg$currPos | 0;
    var peg$posDetailsCache = [{ line: 1, column: 1 }];
    var peg$maxFailPos = peg$currPos;
    var peg$maxFailExpected = options.peg$maxFailExpected || [];
    var peg$silentFails = options.peg$silentFails | 0;
    var peg$result;
    if (options.startRule) {
      if (!(options.startRule in peg$startRuleFunctions)) {
        throw new Error(`Can't start parsing from rule "` + options.startRule + '".');
      }
      peg$startRuleFunction = peg$startRuleFunctions[options.startRule];
    }
    function peg$literalExpectation(text, ignoreCase) {
      return { type: "literal", text, ignoreCase };
    }
    function peg$classExpectation(parts, inverted, ignoreCase) {
      return { type: "class", parts, inverted, ignoreCase };
    }
    function peg$endExpectation() {
      return { type: "end" };
    }
    function peg$otherExpectation(description) {
      return { type: "other", description };
    }
    function peg$computePosDetails(pos) {
      var details = peg$posDetailsCache[pos];
      var p;
      if (details) {
        return details;
      } else {
        if (pos >= peg$posDetailsCache.length) {
          p = peg$posDetailsCache.length - 1;
        } else {
          p = pos;
          while (!peg$posDetailsCache[--p]) {
          }
        }
        details = peg$posDetailsCache[p];
        details = {
          line: details.line,
          column: details.column
        };
        while (p < pos) {
          if (input.charCodeAt(p) === 10) {
            details.line++;
            details.column = 1;
          } else {
            details.column++;
          }
          p++;
        }
        peg$posDetailsCache[pos] = details;
        return details;
      }
    }
    function peg$computeLocation(startPos, endPos, offset) {
      var startPosDetails = peg$computePosDetails(startPos);
      var endPosDetails = peg$computePosDetails(endPos);
      var res = {
        source: peg$source,
        start: {
          offset: startPos,
          line: startPosDetails.line,
          column: startPosDetails.column
        },
        end: {
          offset: endPos,
          line: endPosDetails.line,
          column: endPosDetails.column
        }
      };
      return res;
    }
    function peg$fail(expected) {
      if (peg$currPos < peg$maxFailPos) {
        return;
      }
      if (peg$currPos > peg$maxFailPos) {
        peg$maxFailPos = peg$currPos;
        peg$maxFailExpected = [];
      }
      peg$maxFailExpected.push(expected);
    }
    function peg$buildStructuredError(expected, found, location2) {
      return new peg$SyntaxError(
        peg$SyntaxError.buildMessage(expected, found),
        expected,
        found,
        location2
      );
    }
    function peg$parsepgn() {
      var s0, s1, s2;
      s0 = peg$currPos;
      s1 = peg$parsetagPairSection();
      s2 = peg$parsemoveTextSection();
      s0 = peg$f0(s1, s2);
      return s0;
    }
    function peg$parsetagPairSection() {
      var s0, s1, s2;
      s0 = peg$currPos;
      s1 = [];
      s2 = peg$parsetagPair();
      while (s2 !== peg$FAILED) {
        s1.push(s2);
        s2 = peg$parsetagPair();
      }
      s2 = peg$parse_();
      s0 = peg$f1(s1);
      return s0;
    }
    function peg$parsetagPair() {
      var s0, s2, s4, s6, s7, s8, s10;
      peg$silentFails++;
      s0 = peg$currPos;
      peg$parse_();
      if (input.charCodeAt(peg$currPos) === 91) {
        s2 = peg$c0;
        peg$currPos++;
      } else {
        s2 = peg$FAILED;
        if (peg$silentFails === 0) {
          peg$fail(peg$e1);
        }
      }
      if (s2 !== peg$FAILED) {
        peg$parse_();
        s4 = peg$parsetagName();
        if (s4 !== peg$FAILED) {
          peg$parse_();
          if (input.charCodeAt(peg$currPos) === 34) {
            s6 = peg$c1;
            peg$currPos++;
          } else {
            s6 = peg$FAILED;
            if (peg$silentFails === 0) {
              peg$fail(peg$e2);
            }
          }
          if (s6 !== peg$FAILED) {
            s7 = peg$parsetagValue();
            if (input.charCodeAt(peg$currPos) === 34) {
              s8 = peg$c1;
              peg$currPos++;
            } else {
              s8 = peg$FAILED;
              if (peg$silentFails === 0) {
                peg$fail(peg$e2);
              }
            }
            if (s8 !== peg$FAILED) {
              peg$parse_();
              if (input.charCodeAt(peg$currPos) === 93) {
                s10 = peg$c2;
                peg$currPos++;
              } else {
                s10 = peg$FAILED;
                if (peg$silentFails === 0) {
                  peg$fail(peg$e3);
                }
              }
              if (s10 !== peg$FAILED) {
                s0 = peg$f2(s4, s7);
              } else {
                peg$currPos = s0;
                s0 = peg$FAILED;
              }
            } else {
              peg$currPos = s0;
              s0 = peg$FAILED;
            }
          } else {
            peg$currPos = s0;
            s0 = peg$FAILED;
          }
        } else {
          peg$currPos = s0;
          s0 = peg$FAILED;
        }
      } else {
        peg$currPos = s0;
        s0 = peg$FAILED;
      }
      peg$silentFails--;
      if (s0 === peg$FAILED) {
        if (peg$silentFails === 0) {
          peg$fail(peg$e0);
        }
      }
      return s0;
    }
    function peg$parsetagName() {
      var s0, s1, s2;
      peg$silentFails++;
      s0 = peg$currPos;
      s1 = [];
      s2 = input.charAt(peg$currPos);
      if (peg$r0.test(s2)) {
        peg$currPos++;
      } else {
        s2 = peg$FAILED;
        if (peg$silentFails === 0) {
          peg$fail(peg$e5);
        }
      }
      if (s2 !== peg$FAILED) {
        while (s2 !== peg$FAILED) {
          s1.push(s2);
          s2 = input.charAt(peg$currPos);
          if (peg$r0.test(s2)) {
            peg$currPos++;
          } else {
            s2 = peg$FAILED;
            if (peg$silentFails === 0) {
              peg$fail(peg$e5);
            }
          }
        }
      } else {
        s1 = peg$FAILED;
      }
      if (s1 !== peg$FAILED) {
        s0 = input.substring(s0, peg$currPos);
      } else {
        s0 = s1;
      }
      peg$silentFails--;
      if (s0 === peg$FAILED) {
        s1 = peg$FAILED;
        if (peg$silentFails === 0) {
          peg$fail(peg$e4);
        }
      }
      return s0;
    }
    function peg$parsetagValue() {
      var s0, s1, s2;
      peg$silentFails++;
      s0 = peg$currPos;
      s1 = [];
      s2 = input.charAt(peg$currPos);
      if (peg$r1.test(s2)) {
        peg$currPos++;
      } else {
        s2 = peg$FAILED;
        if (peg$silentFails === 0) {
          peg$fail(peg$e7);
        }
      }
      while (s2 !== peg$FAILED) {
        s1.push(s2);
        s2 = input.charAt(peg$currPos);
        if (peg$r1.test(s2)) {
          peg$currPos++;
        } else {
          s2 = peg$FAILED;
          if (peg$silentFails === 0) {
            peg$fail(peg$e7);
          }
        }
      }
      s0 = input.substring(s0, peg$currPos);
      peg$silentFails--;
      s1 = peg$FAILED;
      if (peg$silentFails === 0) {
        peg$fail(peg$e6);
      }
      return s0;
    }
    function peg$parsemoveTextSection() {
      var s0, s1, s3;
      s0 = peg$currPos;
      s1 = peg$parseline();
      peg$parse_();
      s3 = peg$parsegameTerminationMarker();
      if (s3 === peg$FAILED) {
        s3 = null;
      }
      peg$parse_();
      s0 = peg$f3(s1, s3);
      return s0;
    }
    function peg$parseline() {
      var s0, s1, s2, s3;
      s0 = peg$currPos;
      s1 = peg$parsecomment();
      if (s1 === peg$FAILED) {
        s1 = null;
      }
      s2 = [];
      s3 = peg$parsemove();
      while (s3 !== peg$FAILED) {
        s2.push(s3);
        s3 = peg$parsemove();
      }
      s0 = peg$f4(s1, s2);
      return s0;
    }
    function peg$parsemove() {
      var s0, s4, s5, s6, s7, s8, s9, s10;
      s0 = peg$currPos;
      peg$parse_();
      peg$parsemoveNumber();
      peg$parse_();
      s4 = peg$parsesan();
      if (s4 !== peg$FAILED) {
        s5 = peg$parsesuffixAnnotation();
        if (s5 === peg$FAILED) {
          s5 = null;
        }
        s6 = [];
        s7 = peg$parsenag();
        while (s7 !== peg$FAILED) {
          s6.push(s7);
          s7 = peg$parsenag();
        }
        s7 = peg$parse_();
        s8 = peg$parsecomment();
        if (s8 === peg$FAILED) {
          s8 = null;
        }
        s9 = [];
        s10 = peg$parsevariation();
        while (s10 !== peg$FAILED) {
          s9.push(s10);
          s10 = peg$parsevariation();
        }
        s0 = peg$f5(s4, s5, s6, s8, s9);
      } else {
        peg$currPos = s0;
        s0 = peg$FAILED;
      }
      return s0;
    }
    function peg$parsemoveNumber() {
      var s0, s1, s2, s3, s4, s5;
      peg$silentFails++;
      s0 = peg$currPos;
      s1 = [];
      s2 = input.charAt(peg$currPos);
      if (peg$r2.test(s2)) {
        peg$currPos++;
      } else {
        s2 = peg$FAILED;
        if (peg$silentFails === 0) {
          peg$fail(peg$e9);
        }
      }
      while (s2 !== peg$FAILED) {
        s1.push(s2);
        s2 = input.charAt(peg$currPos);
        if (peg$r2.test(s2)) {
          peg$currPos++;
        } else {
          s2 = peg$FAILED;
          if (peg$silentFails === 0) {
            peg$fail(peg$e9);
          }
        }
      }
      if (input.charCodeAt(peg$currPos) === 46) {
        s2 = peg$c3;
        peg$currPos++;
      } else {
        s2 = peg$FAILED;
        if (peg$silentFails === 0) {
          peg$fail(peg$e10);
        }
      }
      if (s2 !== peg$FAILED) {
        s3 = peg$parse_();
        s4 = [];
        s5 = input.charAt(peg$currPos);
        if (peg$r3.test(s5)) {
          peg$currPos++;
        } else {
          s5 = peg$FAILED;
          if (peg$silentFails === 0) {
            peg$fail(peg$e11);
          }
        }
        while (s5 !== peg$FAILED) {
          s4.push(s5);
          s5 = input.charAt(peg$currPos);
          if (peg$r3.test(s5)) {
            peg$currPos++;
          } else {
            s5 = peg$FAILED;
            if (peg$silentFails === 0) {
              peg$fail(peg$e11);
            }
          }
        }
        s1 = [s1, s2, s3, s4];
        s0 = s1;
      } else {
        peg$currPos = s0;
        s0 = peg$FAILED;
      }
      peg$silentFails--;
      if (s0 === peg$FAILED) {
        s1 = peg$FAILED;
        if (peg$silentFails === 0) {
          peg$fail(peg$e8);
        }
      }
      return s0;
    }
    function peg$parsesan() {
      var s0, s1, s2, s3, s4, s5;
      peg$silentFails++;
      s0 = peg$currPos;
      s1 = peg$currPos;
      if (input.substr(peg$currPos, 5) === peg$c4) {
        s2 = peg$c4;
        peg$currPos += 5;
      } else {
        s2 = peg$FAILED;
        if (peg$silentFails === 0) {
          peg$fail(peg$e13);
        }
      }
      if (s2 === peg$FAILED) {
        if (input.substr(peg$currPos, 3) === peg$c5) {
          s2 = peg$c5;
          peg$currPos += 3;
        } else {
          s2 = peg$FAILED;
          if (peg$silentFails === 0) {
            peg$fail(peg$e14);
          }
        }
        if (s2 === peg$FAILED) {
          if (input.substr(peg$currPos, 5) === peg$c6) {
            s2 = peg$c6;
            peg$currPos += 5;
          } else {
            s2 = peg$FAILED;
            if (peg$silentFails === 0) {
              peg$fail(peg$e15);
            }
          }
          if (s2 === peg$FAILED) {
            if (input.substr(peg$currPos, 3) === peg$c7) {
              s2 = peg$c7;
              peg$currPos += 3;
            } else {
              s2 = peg$FAILED;
              if (peg$silentFails === 0) {
                peg$fail(peg$e16);
              }
            }
            if (s2 === peg$FAILED) {
              s2 = peg$currPos;
              s3 = input.charAt(peg$currPos);
              if (peg$r0.test(s3)) {
                peg$currPos++;
              } else {
                s3 = peg$FAILED;
                if (peg$silentFails === 0) {
                  peg$fail(peg$e5);
                }
              }
              if (s3 !== peg$FAILED) {
                s4 = [];
                s5 = input.charAt(peg$currPos);
                if (peg$r4.test(s5)) {
                  peg$currPos++;
                } else {
                  s5 = peg$FAILED;
                  if (peg$silentFails === 0) {
                    peg$fail(peg$e17);
                  }
                }
                if (s5 !== peg$FAILED) {
                  while (s5 !== peg$FAILED) {
                    s4.push(s5);
                    s5 = input.charAt(peg$currPos);
                    if (peg$r4.test(s5)) {
                      peg$currPos++;
                    } else {
                      s5 = peg$FAILED;
                      if (peg$silentFails === 0) {
                        peg$fail(peg$e17);
                      }
                    }
                  }
                } else {
                  s4 = peg$FAILED;
                }
                if (s4 !== peg$FAILED) {
                  s3 = [s3, s4];
                  s2 = s3;
                } else {
                  peg$currPos = s2;
                  s2 = peg$FAILED;
                }
              } else {
                peg$currPos = s2;
                s2 = peg$FAILED;
              }
            }
          }
        }
      }
      if (s2 !== peg$FAILED) {
        s3 = input.charAt(peg$currPos);
        if (peg$r5.test(s3)) {
          peg$currPos++;
        } else {
          s3 = peg$FAILED;
          if (peg$silentFails === 0) {
            peg$fail(peg$e18);
          }
        }
        if (s3 === peg$FAILED) {
          s3 = null;
        }
        s2 = [s2, s3];
        s1 = s2;
      } else {
        peg$currPos = s1;
        s1 = peg$FAILED;
      }
      if (s1 !== peg$FAILED) {
        s0 = input.substring(s0, peg$currPos);
      } else {
        s0 = s1;
      }
      peg$silentFails--;
      if (s0 === peg$FAILED) {
        s1 = peg$FAILED;
        if (peg$silentFails === 0) {
          peg$fail(peg$e12);
        }
      }
      return s0;
    }
    function peg$parsesuffixAnnotation() {
      var s0, s1, s2;
      peg$silentFails++;
      s0 = peg$currPos;
      s1 = [];
      s2 = input.charAt(peg$currPos);
      if (peg$r6.test(s2)) {
        peg$currPos++;
      } else {
        s2 = peg$FAILED;
        if (peg$silentFails === 0) {
          peg$fail(peg$e20);
        }
      }
      while (s2 !== peg$FAILED) {
        s1.push(s2);
        if (s1.length >= 2) {
          s2 = peg$FAILED;
        } else {
          s2 = input.charAt(peg$currPos);
          if (peg$r6.test(s2)) {
            peg$currPos++;
          } else {
            s2 = peg$FAILED;
            if (peg$silentFails === 0) {
              peg$fail(peg$e20);
            }
          }
        }
      }
      if (s1.length < 1) {
        peg$currPos = s0;
        s0 = peg$FAILED;
      } else {
        s0 = s1;
      }
      peg$silentFails--;
      if (s0 === peg$FAILED) {
        s1 = peg$FAILED;
        if (peg$silentFails === 0) {
          peg$fail(peg$e19);
        }
      }
      return s0;
    }
    function peg$parsenag() {
      var s0, s2, s3, s4, s5;
      peg$silentFails++;
      s0 = peg$currPos;
      peg$parse_();
      if (input.charCodeAt(peg$currPos) === 36) {
        s2 = peg$c8;
        peg$currPos++;
      } else {
        s2 = peg$FAILED;
        if (peg$silentFails === 0) {
          peg$fail(peg$e22);
        }
      }
      if (s2 !== peg$FAILED) {
        s3 = peg$currPos;
        s4 = [];
        s5 = input.charAt(peg$currPos);
        if (peg$r2.test(s5)) {
          peg$currPos++;
        } else {
          s5 = peg$FAILED;
          if (peg$silentFails === 0) {
            peg$fail(peg$e9);
          }
        }
        if (s5 !== peg$FAILED) {
          while (s5 !== peg$FAILED) {
            s4.push(s5);
            s5 = input.charAt(peg$currPos);
            if (peg$r2.test(s5)) {
              peg$currPos++;
            } else {
              s5 = peg$FAILED;
              if (peg$silentFails === 0) {
                peg$fail(peg$e9);
              }
            }
          }
        } else {
          s4 = peg$FAILED;
        }
        if (s4 !== peg$FAILED) {
          s3 = input.substring(s3, peg$currPos);
        } else {
          s3 = s4;
        }
        if (s3 !== peg$FAILED) {
          s0 = peg$f6(s3);
        } else {
          peg$currPos = s0;
          s0 = peg$FAILED;
        }
      } else {
        peg$currPos = s0;
        s0 = peg$FAILED;
      }
      peg$silentFails--;
      if (s0 === peg$FAILED) {
        if (peg$silentFails === 0) {
          peg$fail(peg$e21);
        }
      }
      return s0;
    }
    function peg$parsecomment() {
      var s0;
      s0 = peg$parsebraceComment();
      if (s0 === peg$FAILED) {
        s0 = peg$parserestOfLineComment();
      }
      return s0;
    }
    function peg$parsebraceComment() {
      var s0, s1, s2, s3, s4;
      peg$silentFails++;
      s0 = peg$currPos;
      if (input.charCodeAt(peg$currPos) === 123) {
        s1 = peg$c9;
        peg$currPos++;
      } else {
        s1 = peg$FAILED;
        if (peg$silentFails === 0) {
          peg$fail(peg$e24);
        }
      }
      if (s1 !== peg$FAILED) {
        s2 = peg$currPos;
        s3 = [];
        s4 = input.charAt(peg$currPos);
        if (peg$r7.test(s4)) {
          peg$currPos++;
        } else {
          s4 = peg$FAILED;
          if (peg$silentFails === 0) {
            peg$fail(peg$e25);
          }
        }
        while (s4 !== peg$FAILED) {
          s3.push(s4);
          s4 = input.charAt(peg$currPos);
          if (peg$r7.test(s4)) {
            peg$currPos++;
          } else {
            s4 = peg$FAILED;
            if (peg$silentFails === 0) {
              peg$fail(peg$e25);
            }
          }
        }
        s2 = input.substring(s2, peg$currPos);
        if (input.charCodeAt(peg$currPos) === 125) {
          s3 = peg$c10;
          peg$currPos++;
        } else {
          s3 = peg$FAILED;
          if (peg$silentFails === 0) {
            peg$fail(peg$e26);
          }
        }
        if (s3 !== peg$FAILED) {
          s0 = peg$f7(s2);
        } else {
          peg$currPos = s0;
          s0 = peg$FAILED;
        }
      } else {
        peg$currPos = s0;
        s0 = peg$FAILED;
      }
      peg$silentFails--;
      if (s0 === peg$FAILED) {
        s1 = peg$FAILED;
        if (peg$silentFails === 0) {
          peg$fail(peg$e23);
        }
      }
      return s0;
    }
    function peg$parserestOfLineComment() {
      var s0, s1, s2, s3, s4;
      peg$silentFails++;
      s0 = peg$currPos;
      if (input.charCodeAt(peg$currPos) === 59) {
        s1 = peg$c11;
        peg$currPos++;
      } else {
        s1 = peg$FAILED;
        if (peg$silentFails === 0) {
          peg$fail(peg$e28);
        }
      }
      if (s1 !== peg$FAILED) {
        s2 = peg$currPos;
        s3 = [];
        s4 = input.charAt(peg$currPos);
        if (peg$r8.test(s4)) {
          peg$currPos++;
        } else {
          s4 = peg$FAILED;
          if (peg$silentFails === 0) {
            peg$fail(peg$e29);
          }
        }
        while (s4 !== peg$FAILED) {
          s3.push(s4);
          s4 = input.charAt(peg$currPos);
          if (peg$r8.test(s4)) {
            peg$currPos++;
          } else {
            s4 = peg$FAILED;
            if (peg$silentFails === 0) {
              peg$fail(peg$e29);
            }
          }
        }
        s2 = input.substring(s2, peg$currPos);
        s0 = peg$f8(s2);
      } else {
        peg$currPos = s0;
        s0 = peg$FAILED;
      }
      peg$silentFails--;
      if (s0 === peg$FAILED) {
        s1 = peg$FAILED;
        if (peg$silentFails === 0) {
          peg$fail(peg$e27);
        }
      }
      return s0;
    }
    function peg$parsevariation() {
      var s0, s2, s3, s5;
      peg$silentFails++;
      s0 = peg$currPos;
      peg$parse_();
      if (input.charCodeAt(peg$currPos) === 40) {
        s2 = peg$c12;
        peg$currPos++;
      } else {
        s2 = peg$FAILED;
        if (peg$silentFails === 0) {
          peg$fail(peg$e31);
        }
      }
      if (s2 !== peg$FAILED) {
        s3 = peg$parseline();
        if (s3 !== peg$FAILED) {
          peg$parse_();
          if (input.charCodeAt(peg$currPos) === 41) {
            s5 = peg$c13;
            peg$currPos++;
          } else {
            s5 = peg$FAILED;
            if (peg$silentFails === 0) {
              peg$fail(peg$e32);
            }
          }
          if (s5 !== peg$FAILED) {
            s0 = peg$f9(s3);
          } else {
            peg$currPos = s0;
            s0 = peg$FAILED;
          }
        } else {
          peg$currPos = s0;
          s0 = peg$FAILED;
        }
      } else {
        peg$currPos = s0;
        s0 = peg$FAILED;
      }
      peg$silentFails--;
      if (s0 === peg$FAILED) {
        if (peg$silentFails === 0) {
          peg$fail(peg$e30);
        }
      }
      return s0;
    }
    function peg$parsegameTerminationMarker() {
      var s0, s1, s3;
      peg$silentFails++;
      s0 = peg$currPos;
      if (input.substr(peg$currPos, 3) === peg$c14) {
        s1 = peg$c14;
        peg$currPos += 3;
      } else {
        s1 = peg$FAILED;
        if (peg$silentFails === 0) {
          peg$fail(peg$e34);
        }
      }
      if (s1 === peg$FAILED) {
        if (input.substr(peg$currPos, 3) === peg$c15) {
          s1 = peg$c15;
          peg$currPos += 3;
        } else {
          s1 = peg$FAILED;
          if (peg$silentFails === 0) {
            peg$fail(peg$e35);
          }
        }
        if (s1 === peg$FAILED) {
          if (input.substr(peg$currPos, 7) === peg$c16) {
            s1 = peg$c16;
            peg$currPos += 7;
          } else {
            s1 = peg$FAILED;
            if (peg$silentFails === 0) {
              peg$fail(peg$e36);
            }
          }
          if (s1 === peg$FAILED) {
            if (input.charCodeAt(peg$currPos) === 42) {
              s1 = peg$c17;
              peg$currPos++;
            } else {
              s1 = peg$FAILED;
              if (peg$silentFails === 0) {
                peg$fail(peg$e37);
              }
            }
          }
        }
      }
      if (s1 !== peg$FAILED) {
        peg$parse_();
        s3 = peg$parsecomment();
        if (s3 === peg$FAILED) {
          s3 = null;
        }
        s0 = peg$f10(s1, s3);
      } else {
        peg$currPos = s0;
        s0 = peg$FAILED;
      }
      peg$silentFails--;
      if (s0 === peg$FAILED) {
        s1 = peg$FAILED;
        if (peg$silentFails === 0) {
          peg$fail(peg$e33);
        }
      }
      return s0;
    }
    function peg$parse_() {
      var s0, s1;
      peg$silentFails++;
      s0 = [];
      s1 = input.charAt(peg$currPos);
      if (peg$r9.test(s1)) {
        peg$currPos++;
      } else {
        s1 = peg$FAILED;
        if (peg$silentFails === 0) {
          peg$fail(peg$e39);
        }
      }
      while (s1 !== peg$FAILED) {
        s0.push(s1);
        s1 = input.charAt(peg$currPos);
        if (peg$r9.test(s1)) {
          peg$currPos++;
        } else {
          s1 = peg$FAILED;
          if (peg$silentFails === 0) {
            peg$fail(peg$e39);
          }
        }
      }
      peg$silentFails--;
      s1 = peg$FAILED;
      if (peg$silentFails === 0) {
        peg$fail(peg$e38);
      }
      return s0;
    }
    peg$result = peg$startRuleFunction();
    if (options.peg$library) {
      return (
        /** @type {any} */
        {
          peg$result,
          peg$currPos,
          peg$FAILED,
          peg$maxFailExpected,
          peg$maxFailPos
        }
      );
    }
    if (peg$result !== peg$FAILED && peg$currPos === input.length) {
      return peg$result;
    } else {
      if (peg$result !== peg$FAILED && peg$currPos < input.length) {
        peg$fail(peg$endExpectation());
      }
      throw peg$buildStructuredError(
        peg$maxFailExpected,
        peg$maxFailPos < input.length ? input.charAt(peg$maxFailPos) : null,
        peg$maxFailPos < input.length ? peg$computeLocation(peg$maxFailPos, peg$maxFailPos + 1) : peg$computeLocation(peg$maxFailPos, peg$maxFailPos)
      );
    }
  }
  var MASK64 = 0xffffffffffffffffn;
  function rotl(x, k) {
    return (x << k | x >> 64n - k) & 0xffffffffffffffffn;
  }
  function wrappingMul(x, y) {
    return x * y & MASK64;
  }
  function xoroshiro128(state) {
    return function() {
      let s0 = BigInt(state & MASK64);
      let s1 = BigInt(state >> 64n & MASK64);
      const result = wrappingMul(rotl(wrappingMul(s0, 5n), 7n), 9n);
      s1 ^= s0;
      s0 = (rotl(s0, 24n) ^ s1 ^ s1 << 16n) & MASK64;
      s1 = rotl(s1, 37n);
      state = s1 << 64n | s0;
      return result;
    };
  }
  var rand = xoroshiro128(0xa187eb39cdcaed8f31c4b365b102e01en);
  var PIECE_KEYS = Array.from({ length: 2 }, () => Array.from({ length: 6 }, () => Array.from({ length: 128 }, () => rand())));
  var EP_KEYS = Array.from({ length: 8 }, () => rand());
  var CASTLING_KEYS = Array.from({ length: 16 }, () => rand());
  var SIDE_KEY = rand();
  var WHITE = "w";
  var BLACK = "b";
  var PAWN = "p";
  var KNIGHT = "n";
  var BISHOP = "b";
  var ROOK = "r";
  var QUEEN = "q";
  var KING = "k";
  var DEFAULT_POSITION = "rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1";
  var Move = class {
    color;
    from;
    to;
    piece;
    captured;
    promotion;
    /**
     * @deprecated This field is deprecated and will be removed in version 2.0.0.
     * Please use move descriptor functions instead: `isCapture`, `isPromotion`,
     * `isEnPassant`, `isKingsideCastle`, `isQueensideCastle`, `isCastle`, and
     * `isBigPawn`
     */
    flags;
    san;
    lan;
    before;
    after;
    constructor(chess, internal) {
      const { color, piece, from, to, flags, captured, promotion } = internal;
      const fromAlgebraic = algebraic(from);
      const toAlgebraic = algebraic(to);
      this.color = color;
      this.piece = piece;
      this.from = fromAlgebraic;
      this.to = toAlgebraic;
      this.san = chess["_moveToSan"](internal, chess["_moves"]({ legal: true }));
      this.lan = fromAlgebraic + toAlgebraic;
      this.before = chess.fen();
      chess["_makeMove"](internal);
      this.after = chess.fen();
      chess["_undoMove"]();
      this.flags = "";
      for (const flag in BITS) {
        if (BITS[flag] & flags) {
          this.flags += FLAGS[flag];
        }
      }
      if (captured) {
        this.captured = captured;
      }
      if (promotion) {
        this.promotion = promotion;
        this.lan += promotion;
      }
    }
    isCapture() {
      return this.flags.indexOf(FLAGS["CAPTURE"]) > -1;
    }
    isPromotion() {
      return this.flags.indexOf(FLAGS["PROMOTION"]) > -1;
    }
    isEnPassant() {
      return this.flags.indexOf(FLAGS["EP_CAPTURE"]) > -1;
    }
    isKingsideCastle() {
      return this.flags.indexOf(FLAGS["KSIDE_CASTLE"]) > -1;
    }
    isQueensideCastle() {
      return this.flags.indexOf(FLAGS["QSIDE_CASTLE"]) > -1;
    }
    isBigPawn() {
      return this.flags.indexOf(FLAGS["BIG_PAWN"]) > -1;
    }
  };
  var EMPTY = -1;
  var FLAGS = {
    NORMAL: "n",
    CAPTURE: "c",
    BIG_PAWN: "b",
    EP_CAPTURE: "e",
    PROMOTION: "p",
    KSIDE_CASTLE: "k",
    QSIDE_CASTLE: "q",
    NULL_MOVE: "-"
  };
  var BITS = {
    NORMAL: 1,
    CAPTURE: 2,
    BIG_PAWN: 4,
    EP_CAPTURE: 8,
    PROMOTION: 16,
    KSIDE_CASTLE: 32,
    QSIDE_CASTLE: 64,
    NULL_MOVE: 128
  };
  var SEVEN_TAG_ROSTER = {
    Event: "?",
    Site: "?",
    Date: "????.??.??",
    Round: "?",
    White: "?",
    Black: "?",
    Result: "*"
  };
  var SUPLEMENTAL_TAGS = {
    WhiteTitle: null,
    BlackTitle: null,
    WhiteElo: null,
    BlackElo: null,
    WhiteUSCF: null,
    BlackUSCF: null,
    WhiteNA: null,
    BlackNA: null,
    WhiteType: null,
    BlackType: null,
    EventDate: null,
    EventSponsor: null,
    Section: null,
    Stage: null,
    Board: null,
    Opening: null,
    Variation: null,
    SubVariation: null,
    ECO: null,
    NIC: null,
    Time: null,
    UTCTime: null,
    UTCDate: null,
    TimeControl: null,
    SetUp: null,
    FEN: null,
    Termination: null,
    Annotator: null,
    Mode: null,
    PlyCount: null
  };
  var HEADER_TEMPLATE = {
    ...SEVEN_TAG_ROSTER,
    ...SUPLEMENTAL_TAGS
  };
  var Ox88 = {
    a8: 0,
    b8: 1,
    c8: 2,
    d8: 3,
    e8: 4,
    f8: 5,
    g8: 6,
    h8: 7,
    a7: 16,
    b7: 17,
    c7: 18,
    d7: 19,
    e7: 20,
    f7: 21,
    g7: 22,
    h7: 23,
    a6: 32,
    b6: 33,
    c6: 34,
    d6: 35,
    e6: 36,
    f6: 37,
    g6: 38,
    h6: 39,
    a5: 48,
    b5: 49,
    c5: 50,
    d5: 51,
    e5: 52,
    f5: 53,
    g5: 54,
    h5: 55,
    a4: 64,
    b4: 65,
    c4: 66,
    d4: 67,
    e4: 68,
    f4: 69,
    g4: 70,
    h4: 71,
    a3: 80,
    b3: 81,
    c3: 82,
    d3: 83,
    e3: 84,
    f3: 85,
    g3: 86,
    h3: 87,
    a2: 96,
    b2: 97,
    c2: 98,
    d2: 99,
    e2: 100,
    f2: 101,
    g2: 102,
    h2: 103,
    a1: 112,
    b1: 113,
    c1: 114,
    d1: 115,
    e1: 116,
    f1: 117,
    g1: 118,
    h1: 119
  };
  var PAWN_OFFSETS = {
    b: [16, 32, 17, 15],
    w: [-16, -32, -17, -15]
  };
  var PIECE_OFFSETS = {
    n: [-18, -33, -31, -14, 18, 33, 31, 14],
    b: [-17, -15, 17, 15],
    r: [-16, 1, 16, -1],
    q: [-17, -16, -15, 1, 17, 16, 15, -1],
    k: [-17, -16, -15, 1, 17, 16, 15, -1]
  };
  var ATTACKS = [
    20,
    0,
    0,
    0,
    0,
    0,
    0,
    24,
    0,
    0,
    0,
    0,
    0,
    0,
    20,
    0,
    0,
    20,
    0,
    0,
    0,
    0,
    0,
    24,
    0,
    0,
    0,
    0,
    0,
    20,
    0,
    0,
    0,
    0,
    20,
    0,
    0,
    0,
    0,
    24,
    0,
    0,
    0,
    0,
    20,
    0,
    0,
    0,
    0,
    0,
    0,
    20,
    0,
    0,
    0,
    24,
    0,
    0,
    0,
    20,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    20,
    0,
    0,
    24,
    0,
    0,
    20,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    20,
    2,
    24,
    2,
    20,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    2,
    53,
    56,
    53,
    2,
    0,
    0,
    0,
    0,
    0,
    0,
    24,
    24,
    24,
    24,
    24,
    24,
    56,
    0,
    56,
    24,
    24,
    24,
    24,
    24,
    24,
    0,
    0,
    0,
    0,
    0,
    0,
    2,
    53,
    56,
    53,
    2,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    20,
    2,
    24,
    2,
    20,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    20,
    0,
    0,
    24,
    0,
    0,
    20,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    20,
    0,
    0,
    0,
    24,
    0,
    0,
    0,
    20,
    0,
    0,
    0,
    0,
    0,
    0,
    20,
    0,
    0,
    0,
    0,
    24,
    0,
    0,
    0,
    0,
    20,
    0,
    0,
    0,
    0,
    20,
    0,
    0,
    0,
    0,
    0,
    24,
    0,
    0,
    0,
    0,
    0,
    20,
    0,
    0,
    20,
    0,
    0,
    0,
    0,
    0,
    0,
    24,
    0,
    0,
    0,
    0,
    0,
    0,
    20
  ];
  var RAYS = [
    17,
    0,
    0,
    0,
    0,
    0,
    0,
    16,
    0,
    0,
    0,
    0,
    0,
    0,
    15,
    0,
    0,
    17,
    0,
    0,
    0,
    0,
    0,
    16,
    0,
    0,
    0,
    0,
    0,
    15,
    0,
    0,
    0,
    0,
    17,
    0,
    0,
    0,
    0,
    16,
    0,
    0,
    0,
    0,
    15,
    0,
    0,
    0,
    0,
    0,
    0,
    17,
    0,
    0,
    0,
    16,
    0,
    0,
    0,
    15,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    17,
    0,
    0,
    16,
    0,
    0,
    15,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    17,
    0,
    16,
    0,
    15,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    17,
    16,
    15,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    0,
    -1,
    -1,
    -1,
    -1,
    -1,
    -1,
    -1,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    -15,
    -16,
    -17,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    -15,
    0,
    -16,
    0,
    -17,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    -15,
    0,
    0,
    -16,
    0,
    0,
    -17,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    -15,
    0,
    0,
    0,
    -16,
    0,
    0,
    0,
    -17,
    0,
    0,
    0,
    0,
    0,
    0,
    -15,
    0,
    0,
    0,
    0,
    -16,
    0,
    0,
    0,
    0,
    -17,
    0,
    0,
    0,
    0,
    -15,
    0,
    0,
    0,
    0,
    0,
    -16,
    0,
    0,
    0,
    0,
    0,
    -17,
    0,
    0,
    -15,
    0,
    0,
    0,
    0,
    0,
    0,
    -16,
    0,
    0,
    0,
    0,
    0,
    0,
    -17
  ];
  var PIECE_MASKS = { p: 1, n: 2, b: 4, r: 8, q: 16, k: 32 };
  var SYMBOLS = "pnbrqkPNBRQK";
  var PROMOTIONS = [KNIGHT, BISHOP, ROOK, QUEEN];
  var RANK_1 = 7;
  var RANK_2 = 6;
  var RANK_7 = 1;
  var RANK_8 = 0;
  var SIDES = {
    [KING]: BITS.KSIDE_CASTLE,
    [QUEEN]: BITS.QSIDE_CASTLE
  };
  var ROOKS = {
    w: [
      { square: Ox88.a1, flag: BITS.QSIDE_CASTLE },
      { square: Ox88.h1, flag: BITS.KSIDE_CASTLE }
    ],
    b: [
      { square: Ox88.a8, flag: BITS.QSIDE_CASTLE },
      { square: Ox88.h8, flag: BITS.KSIDE_CASTLE }
    ]
  };
  var SECOND_RANK = { b: RANK_7, w: RANK_2 };
  var SAN_NULLMOVE = "--";
  function rank(square) {
    return square >> 4;
  }
  function file(square) {
    return square & 15;
  }
  function isDigit(c) {
    return "0123456789".indexOf(c) !== -1;
  }
  function algebraic(square) {
    const f = file(square);
    const r = rank(square);
    return "abcdefgh".substring(f, f + 1) + "87654321".substring(r, r + 1);
  }
  function swapColor(color) {
    return color === WHITE ? BLACK : WHITE;
  }
  function validateFen(fen) {
    const tokens = fen.split(/\s+/);
    if (tokens.length !== 6) {
      return {
        ok: false,
        error: "Invalid FEN: must contain six space-delimited fields"
      };
    }
    const moveNumber = parseInt(tokens[5], 10);
    if (isNaN(moveNumber) || moveNumber <= 0) {
      return {
        ok: false,
        error: "Invalid FEN: move number must be a positive integer"
      };
    }
    const halfMoves = parseInt(tokens[4], 10);
    if (isNaN(halfMoves) || halfMoves < 0) {
      return {
        ok: false,
        error: "Invalid FEN: half move counter number must be a non-negative integer"
      };
    }
    if (!/^(-|[abcdefgh][36])$/.test(tokens[3])) {
      return { ok: false, error: "Invalid FEN: en-passant square is invalid" };
    }
    if (/[^kKqQ-]/.test(tokens[2])) {
      return { ok: false, error: "Invalid FEN: castling availability is invalid" };
    }
    if (!/^(w|b)$/.test(tokens[1])) {
      return { ok: false, error: "Invalid FEN: side-to-move is invalid" };
    }
    const rows = tokens[0].split("/");
    if (rows.length !== 8) {
      return {
        ok: false,
        error: "Invalid FEN: piece data does not contain 8 '/'-delimited rows"
      };
    }
    for (let i = 0; i < rows.length; i++) {
      let sumFields = 0;
      let previousWasNumber = false;
      for (let k = 0; k < rows[i].length; k++) {
        if (isDigit(rows[i][k])) {
          if (previousWasNumber) {
            return {
              ok: false,
              error: "Invalid FEN: piece data is invalid (consecutive number)"
            };
          }
          sumFields += parseInt(rows[i][k], 10);
          previousWasNumber = true;
        } else {
          if (!/^[prnbqkPRNBQK]$/.test(rows[i][k])) {
            return {
              ok: false,
              error: "Invalid FEN: piece data is invalid (invalid piece)"
            };
          }
          sumFields += 1;
          previousWasNumber = false;
        }
      }
      if (sumFields !== 8) {
        return {
          ok: false,
          error: "Invalid FEN: piece data is invalid (too many squares in rank)"
        };
      }
    }
    if (tokens[3][1] == "3" && tokens[1] == "w" || tokens[3][1] == "6" && tokens[1] == "b") {
      return { ok: false, error: "Invalid FEN: illegal en-passant square" };
    }
    const kings = [
      { color: "white", regex: /K/g },
      { color: "black", regex: /k/g }
    ];
    for (const { color, regex } of kings) {
      if (!regex.test(tokens[0])) {
        return { ok: false, error: `Invalid FEN: missing ${color} king` };
      }
      if ((tokens[0].match(regex) || []).length > 1) {
        return { ok: false, error: `Invalid FEN: too many ${color} kings` };
      }
    }
    if (Array.from(rows[0] + rows[7]).some((char) => char.toUpperCase() === "P")) {
      return {
        ok: false,
        error: "Invalid FEN: some pawns are on the edge rows"
      };
    }
    return { ok: true };
  }
  function getDisambiguator(move, moves) {
    const from = move.from;
    const to = move.to;
    const piece = move.piece;
    let ambiguities = 0;
    let sameRank = 0;
    let sameFile = 0;
    for (let i = 0, len = moves.length; i < len; i++) {
      const ambigFrom = moves[i].from;
      const ambigTo = moves[i].to;
      const ambigPiece = moves[i].piece;
      if (piece === ambigPiece && from !== ambigFrom && to === ambigTo) {
        ambiguities++;
        if (rank(from) === rank(ambigFrom)) {
          sameRank++;
        }
        if (file(from) === file(ambigFrom)) {
          sameFile++;
        }
      }
    }
    if (ambiguities > 0) {
      if (sameRank > 0 && sameFile > 0) {
        return algebraic(from);
      } else if (sameFile > 0) {
        return algebraic(from).charAt(1);
      } else {
        return algebraic(from).charAt(0);
      }
    }
    return "";
  }
  function addMove(moves, color, from, to, piece, captured = void 0, flags = BITS.NORMAL) {
    const r = rank(to);
    if (piece === PAWN && (r === RANK_1 || r === RANK_8)) {
      for (let i = 0; i < PROMOTIONS.length; i++) {
        const promotion = PROMOTIONS[i];
        moves.push({
          color,
          from,
          to,
          piece,
          captured,
          promotion,
          flags: flags | BITS.PROMOTION
        });
      }
    } else {
      moves.push({
        color,
        from,
        to,
        piece,
        captured,
        flags
      });
    }
  }
  function inferPieceType(san) {
    let pieceType = san.charAt(0);
    if (pieceType >= "a" && pieceType <= "h") {
      const matches = san.match(/[a-h]\d.*[a-h]\d/);
      if (matches) {
        return void 0;
      }
      return PAWN;
    }
    pieceType = pieceType.toLowerCase();
    if (pieceType === "o") {
      return KING;
    }
    return pieceType;
  }
  function strippedSan(move) {
    return move.replace(/=/, "").replace(/[+#]?[?!]*$/, "");
  }
  var Chess = class {
    _board = new Array(128);
    _turn = WHITE;
    _header = {};
    _kings = { w: EMPTY, b: EMPTY };
    _epSquare = -1;
    _halfMoves = 0;
    _moveNumber = 0;
    _history = [];
    _comments = {};
    _castling = { w: 0, b: 0 };
    _hash = 0n;
    // tracks number of times a position has been seen for repetition checking
    _positionCount = /* @__PURE__ */ new Map();
    constructor(fen = DEFAULT_POSITION, { skipValidation = false } = {}) {
      this.load(fen, { skipValidation });
    }
    clear({ preserveHeaders = false } = {}) {
      this._board = new Array(128);
      this._kings = { w: EMPTY, b: EMPTY };
      this._turn = WHITE;
      this._castling = { w: 0, b: 0 };
      this._epSquare = EMPTY;
      this._halfMoves = 0;
      this._moveNumber = 1;
      this._history = [];
      this._comments = {};
      this._header = preserveHeaders ? this._header : { ...HEADER_TEMPLATE };
      this._hash = this._computeHash();
      this._positionCount = /* @__PURE__ */ new Map();
      this._header["SetUp"] = null;
      this._header["FEN"] = null;
    }
    load(fen, { skipValidation = false, preserveHeaders = false } = {}) {
      let tokens = fen.split(/\s+/);
      if (tokens.length >= 2 && tokens.length < 6) {
        const adjustments = ["-", "-", "0", "1"];
        fen = tokens.concat(adjustments.slice(-(6 - tokens.length))).join(" ");
      }
      tokens = fen.split(/\s+/);
      if (!skipValidation) {
        const { ok, error } = validateFen(fen);
        if (!ok) {
          throw new Error(error);
        }
      }
      const position = tokens[0];
      let square = 0;
      this.clear({ preserveHeaders });
      for (let i = 0; i < position.length; i++) {
        const piece = position.charAt(i);
        if (piece === "/") {
          square += 8;
        } else if (isDigit(piece)) {
          square += parseInt(piece, 10);
        } else {
          const color = piece < "a" ? WHITE : BLACK;
          this._put({ type: piece.toLowerCase(), color }, algebraic(square));
          square++;
        }
      }
      this._turn = tokens[1];
      if (tokens[2].indexOf("K") > -1) {
        this._castling.w |= BITS.KSIDE_CASTLE;
      }
      if (tokens[2].indexOf("Q") > -1) {
        this._castling.w |= BITS.QSIDE_CASTLE;
      }
      if (tokens[2].indexOf("k") > -1) {
        this._castling.b |= BITS.KSIDE_CASTLE;
      }
      if (tokens[2].indexOf("q") > -1) {
        this._castling.b |= BITS.QSIDE_CASTLE;
      }
      this._epSquare = tokens[3] === "-" ? EMPTY : Ox88[tokens[3]];
      this._halfMoves = parseInt(tokens[4], 10);
      this._moveNumber = parseInt(tokens[5], 10);
      this._hash = this._computeHash();
      this._updateSetup(fen);
      this._incPositionCount();
    }
    fen({ forceEnpassantSquare = false } = {}) {
      let empty = 0;
      let fen = "";
      for (let i = Ox88.a8; i <= Ox88.h1; i++) {
        if (this._board[i]) {
          if (empty > 0) {
            fen += empty;
            empty = 0;
          }
          const { color, type: piece } = this._board[i];
          fen += color === WHITE ? piece.toUpperCase() : piece.toLowerCase();
        } else {
          empty++;
        }
        if (i + 1 & 136) {
          if (empty > 0) {
            fen += empty;
          }
          if (i !== Ox88.h1) {
            fen += "/";
          }
          empty = 0;
          i += 8;
        }
      }
      let castling = "";
      if (this._castling[WHITE] & BITS.KSIDE_CASTLE) {
        castling += "K";
      }
      if (this._castling[WHITE] & BITS.QSIDE_CASTLE) {
        castling += "Q";
      }
      if (this._castling[BLACK] & BITS.KSIDE_CASTLE) {
        castling += "k";
      }
      if (this._castling[BLACK] & BITS.QSIDE_CASTLE) {
        castling += "q";
      }
      castling = castling || "-";
      let epSquare = "-";
      if (this._epSquare !== EMPTY) {
        if (forceEnpassantSquare) {
          epSquare = algebraic(this._epSquare);
        } else {
          const bigPawnSquare = this._epSquare + (this._turn === WHITE ? 16 : -16);
          const squares = [bigPawnSquare + 1, bigPawnSquare - 1];
          for (const square of squares) {
            if (square & 136) {
              continue;
            }
            const color = this._turn;
            if (this._board[square]?.color === color && this._board[square]?.type === PAWN) {
              this._makeMove({
                color,
                from: square,
                to: this._epSquare,
                piece: PAWN,
                captured: PAWN,
                flags: BITS.EP_CAPTURE
              });
              const isLegal = !this._isKingAttacked(color);
              this._undoMove();
              if (isLegal) {
                epSquare = algebraic(this._epSquare);
                break;
              }
            }
          }
        }
      }
      return [
        fen,
        this._turn,
        castling,
        epSquare,
        this._halfMoves,
        this._moveNumber
      ].join(" ");
    }
    _pieceKey(i) {
      if (!this._board[i]) {
        return 0n;
      }
      const { color, type } = this._board[i];
      const colorIndex = {
        w: 0,
        b: 1
      }[color];
      const typeIndex = {
        p: 0,
        n: 1,
        b: 2,
        r: 3,
        q: 4,
        k: 5
      }[type];
      return PIECE_KEYS[colorIndex][typeIndex][i];
    }
    _epKey() {
      return this._epSquare === EMPTY ? 0n : EP_KEYS[this._epSquare & 7];
    }
    _castlingKey() {
      const index = this._castling.w >> 5 | this._castling.b >> 3;
      return CASTLING_KEYS[index];
    }
    _computeHash() {
      let hash = 0n;
      for (let i = Ox88.a8; i <= Ox88.h1; i++) {
        if (i & 136) {
          i += 7;
          continue;
        }
        if (this._board[i]) {
          hash ^= this._pieceKey(i);
        }
      }
      hash ^= this._epKey();
      hash ^= this._castlingKey();
      if (this._turn === "b") {
        hash ^= SIDE_KEY;
      }
      return hash;
    }
    /*
     * Called when the initial board setup is changed with put() or remove().
     * modifies the SetUp and FEN properties of the header object. If the FEN
     * is equal to the default position, the SetUp and FEN are deleted the setup
     * is only updated if history.length is zero, ie moves haven't been made.
     */
    _updateSetup(fen) {
      if (this._history.length > 0)
        return;
      if (fen !== DEFAULT_POSITION) {
        this._header["SetUp"] = "1";
        this._header["FEN"] = fen;
      } else {
        this._header["SetUp"] = null;
        this._header["FEN"] = null;
      }
    }
    reset() {
      this.load(DEFAULT_POSITION);
    }
    get(square) {
      return this._board[Ox88[square]];
    }
    findPiece(piece) {
      const squares = [];
      for (let i = Ox88.a8; i <= Ox88.h1; i++) {
        if (i & 136) {
          i += 7;
          continue;
        }
        if (!this._board[i] || this._board[i]?.color !== piece.color) {
          continue;
        }
        if (this._board[i].color === piece.color && this._board[i].type === piece.type) {
          squares.push(algebraic(i));
        }
      }
      return squares;
    }
    put({ type, color }, square) {
      if (this._put({ type, color }, square)) {
        this._updateCastlingRights();
        this._updateEnPassantSquare();
        this._updateSetup(this.fen());
        return true;
      }
      return false;
    }
    _set(sq, piece) {
      this._hash ^= this._pieceKey(sq);
      this._board[sq] = piece;
      this._hash ^= this._pieceKey(sq);
    }
    _put({ type, color }, square) {
      if (SYMBOLS.indexOf(type.toLowerCase()) === -1) {
        return false;
      }
      if (!(square in Ox88)) {
        return false;
      }
      const sq = Ox88[square];
      if (type == KING && !(this._kings[color] == EMPTY || this._kings[color] == sq)) {
        return false;
      }
      const currentPieceOnSquare = this._board[sq];
      if (currentPieceOnSquare && currentPieceOnSquare.type === KING) {
        this._kings[currentPieceOnSquare.color] = EMPTY;
      }
      this._set(sq, { type, color });
      if (type === KING) {
        this._kings[color] = sq;
      }
      return true;
    }
    _clear(sq) {
      this._hash ^= this._pieceKey(sq);
      delete this._board[sq];
    }
    remove(square) {
      const piece = this.get(square);
      this._clear(Ox88[square]);
      if (piece && piece.type === KING) {
        this._kings[piece.color] = EMPTY;
      }
      this._updateCastlingRights();
      this._updateEnPassantSquare();
      this._updateSetup(this.fen());
      return piece;
    }
    _updateCastlingRights() {
      this._hash ^= this._castlingKey();
      const whiteKingInPlace = this._board[Ox88.e1]?.type === KING && this._board[Ox88.e1]?.color === WHITE;
      const blackKingInPlace = this._board[Ox88.e8]?.type === KING && this._board[Ox88.e8]?.color === BLACK;
      if (!whiteKingInPlace || this._board[Ox88.a1]?.type !== ROOK || this._board[Ox88.a1]?.color !== WHITE) {
        this._castling.w &= -65;
      }
      if (!whiteKingInPlace || this._board[Ox88.h1]?.type !== ROOK || this._board[Ox88.h1]?.color !== WHITE) {
        this._castling.w &= -33;
      }
      if (!blackKingInPlace || this._board[Ox88.a8]?.type !== ROOK || this._board[Ox88.a8]?.color !== BLACK) {
        this._castling.b &= -65;
      }
      if (!blackKingInPlace || this._board[Ox88.h8]?.type !== ROOK || this._board[Ox88.h8]?.color !== BLACK) {
        this._castling.b &= -33;
      }
      this._hash ^= this._castlingKey();
    }
    _updateEnPassantSquare() {
      if (this._epSquare === EMPTY) {
        return;
      }
      const startSquare = this._epSquare + (this._turn === WHITE ? -16 : 16);
      const currentSquare = this._epSquare + (this._turn === WHITE ? 16 : -16);
      const attackers = [currentSquare + 1, currentSquare - 1];
      if (this._board[startSquare] !== null || this._board[this._epSquare] !== null || this._board[currentSquare]?.color !== swapColor(this._turn) || this._board[currentSquare]?.type !== PAWN) {
        this._hash ^= this._epKey();
        this._epSquare = EMPTY;
        return;
      }
      const canCapture = (square) => !(square & 136) && this._board[square]?.color === this._turn && this._board[square]?.type === PAWN;
      if (!attackers.some(canCapture)) {
        this._hash ^= this._epKey();
        this._epSquare = EMPTY;
      }
    }
    _attacked(color, square, verbose) {
      const attackers = [];
      for (let i = Ox88.a8; i <= Ox88.h1; i++) {
        if (i & 136) {
          i += 7;
          continue;
        }
        if (this._board[i] === void 0 || this._board[i].color !== color) {
          continue;
        }
        const piece = this._board[i];
        const difference = i - square;
        if (difference === 0) {
          continue;
        }
        const index = difference + 119;
        if (ATTACKS[index] & PIECE_MASKS[piece.type]) {
          if (piece.type === PAWN) {
            if (difference > 0 && piece.color === WHITE || difference <= 0 && piece.color === BLACK) {
              if (!verbose) {
                return true;
              } else {
                attackers.push(algebraic(i));
              }
            }
            continue;
          }
          if (piece.type === "n" || piece.type === "k") {
            if (!verbose) {
              return true;
            } else {
              attackers.push(algebraic(i));
              continue;
            }
          }
          const offset = RAYS[index];
          let j = i + offset;
          let blocked = false;
          while (j !== square) {
            if (this._board[j] != null) {
              blocked = true;
              break;
            }
            j += offset;
          }
          if (!blocked) {
            if (!verbose) {
              return true;
            } else {
              attackers.push(algebraic(i));
              continue;
            }
          }
        }
      }
      if (verbose) {
        return attackers;
      } else {
        return false;
      }
    }
    attackers(square, attackedBy) {
      if (!attackedBy) {
        return this._attacked(this._turn, Ox88[square], true);
      } else {
        return this._attacked(attackedBy, Ox88[square], true);
      }
    }
    _isKingAttacked(color) {
      const square = this._kings[color];
      return square === -1 ? false : this._attacked(swapColor(color), square);
    }
    hash() {
      return this._hash.toString(16);
    }
    isAttacked(square, attackedBy) {
      return this._attacked(attackedBy, Ox88[square]);
    }
    isCheck() {
      return this._isKingAttacked(this._turn);
    }
    inCheck() {
      return this.isCheck();
    }
    isCheckmate() {
      return this.isCheck() && this._moves().length === 0;
    }
    isStalemate() {
      return !this.isCheck() && this._moves().length === 0;
    }
    isInsufficientMaterial() {
      const pieces2 = {
        b: 0,
        n: 0,
        r: 0,
        q: 0,
        k: 0,
        p: 0
      };
      const bishops = [];
      let numPieces = 0;
      let squareColor = 0;
      for (let i = Ox88.a8; i <= Ox88.h1; i++) {
        squareColor = (squareColor + 1) % 2;
        if (i & 136) {
          i += 7;
          continue;
        }
        const piece = this._board[i];
        if (piece) {
          pieces2[piece.type] = piece.type in pieces2 ? pieces2[piece.type] + 1 : 1;
          if (piece.type === BISHOP) {
            bishops.push(squareColor);
          }
          numPieces++;
        }
      }
      if (numPieces === 2) {
        return true;
      } else if (
        // k vs. kn .... or .... k vs. kb
        numPieces === 3 && (pieces2[BISHOP] === 1 || pieces2[KNIGHT] === 1)
      ) {
        return true;
      } else if (numPieces === pieces2[BISHOP] + 2) {
        let sum = 0;
        const len = bishops.length;
        for (let i = 0; i < len; i++) {
          sum += bishops[i];
        }
        if (sum === 0 || sum === len) {
          return true;
        }
      }
      return false;
    }
    isThreefoldRepetition() {
      return this._getPositionCount(this._hash) >= 3;
    }
    isDrawByFiftyMoves() {
      return this._halfMoves >= 100;
    }
    isDraw() {
      return this.isDrawByFiftyMoves() || this.isStalemate() || this.isInsufficientMaterial() || this.isThreefoldRepetition();
    }
    isGameOver() {
      return this.isCheckmate() || this.isDraw();
    }
    moves({ verbose = false, square = void 0, piece = void 0 } = {}) {
      const moves = this._moves({ square, piece });
      if (verbose) {
        return moves.map((move) => new Move(this, move));
      } else {
        return moves.map((move) => this._moveToSan(move, moves));
      }
    }
    _moves({ legal = true, piece = void 0, square = void 0 } = {}) {
      const forSquare = square ? square.toLowerCase() : void 0;
      const forPiece = piece?.toLowerCase();
      const moves = [];
      const us = this._turn;
      const them = swapColor(us);
      let firstSquare = Ox88.a8;
      let lastSquare = Ox88.h1;
      let singleSquare = false;
      if (forSquare) {
        if (!(forSquare in Ox88)) {
          return [];
        } else {
          firstSquare = lastSquare = Ox88[forSquare];
          singleSquare = true;
        }
      }
      for (let from = firstSquare; from <= lastSquare; from++) {
        if (from & 136) {
          from += 7;
          continue;
        }
        if (!this._board[from] || this._board[from].color === them) {
          continue;
        }
        const { type } = this._board[from];
        let to;
        if (type === PAWN) {
          if (forPiece && forPiece !== type)
            continue;
          to = from + PAWN_OFFSETS[us][0];
          if (!this._board[to]) {
            addMove(moves, us, from, to, PAWN);
            to = from + PAWN_OFFSETS[us][1];
            if (SECOND_RANK[us] === rank(from) && !this._board[to]) {
              addMove(moves, us, from, to, PAWN, void 0, BITS.BIG_PAWN);
            }
          }
          for (let j = 2; j < 4; j++) {
            to = from + PAWN_OFFSETS[us][j];
            if (to & 136)
              continue;
            if (this._board[to]?.color === them) {
              addMove(moves, us, from, to, PAWN, this._board[to].type, BITS.CAPTURE);
            } else if (to === this._epSquare) {
              addMove(moves, us, from, to, PAWN, PAWN, BITS.EP_CAPTURE);
            }
          }
        } else {
          if (forPiece && forPiece !== type)
            continue;
          for (let j = 0, len = PIECE_OFFSETS[type].length; j < len; j++) {
            const offset = PIECE_OFFSETS[type][j];
            to = from;
            while (true) {
              to += offset;
              if (to & 136)
                break;
              if (!this._board[to]) {
                addMove(moves, us, from, to, type);
              } else {
                if (this._board[to].color === us)
                  break;
                addMove(moves, us, from, to, type, this._board[to].type, BITS.CAPTURE);
                break;
              }
              if (type === KNIGHT || type === KING)
                break;
            }
          }
        }
      }
      if (forPiece === void 0 || forPiece === KING) {
        if (!singleSquare || lastSquare === this._kings[us]) {
          if (this._castling[us] & BITS.KSIDE_CASTLE) {
            const castlingFrom = this._kings[us];
            const castlingTo = castlingFrom + 2;
            if (!this._board[castlingFrom + 1] && !this._board[castlingTo] && !this._attacked(them, this._kings[us]) && !this._attacked(them, castlingFrom + 1) && !this._attacked(them, castlingTo)) {
              addMove(moves, us, this._kings[us], castlingTo, KING, void 0, BITS.KSIDE_CASTLE);
            }
          }
          if (this._castling[us] & BITS.QSIDE_CASTLE) {
            const castlingFrom = this._kings[us];
            const castlingTo = castlingFrom - 2;
            if (!this._board[castlingFrom - 1] && !this._board[castlingFrom - 2] && !this._board[castlingFrom - 3] && !this._attacked(them, this._kings[us]) && !this._attacked(them, castlingFrom - 1) && !this._attacked(them, castlingTo)) {
              addMove(moves, us, this._kings[us], castlingTo, KING, void 0, BITS.QSIDE_CASTLE);
            }
          }
        }
      }
      if (!legal || this._kings[us] === -1) {
        return moves;
      }
      const legalMoves = [];
      for (let i = 0, len = moves.length; i < len; i++) {
        this._makeMove(moves[i]);
        if (!this._isKingAttacked(us)) {
          legalMoves.push(moves[i]);
        }
        this._undoMove();
      }
      return legalMoves;
    }
    move(move, { strict = false } = {}) {
      let moveObj = null;
      if (typeof move === "string") {
        moveObj = this._moveFromSan(move, strict);
      } else if (move === null) {
        moveObj = this._moveFromSan(SAN_NULLMOVE, strict);
      } else if (typeof move === "object") {
        const moves = this._moves();
        for (let i = 0, len = moves.length; i < len; i++) {
          if (move.from === algebraic(moves[i].from) && move.to === algebraic(moves[i].to) && (!("promotion" in moves[i]) || move.promotion === moves[i].promotion)) {
            moveObj = moves[i];
            break;
          }
        }
      }
      if (!moveObj) {
        if (typeof move === "string") {
          throw new Error(`Invalid move: ${move}`);
        } else {
          throw new Error(`Invalid move: ${JSON.stringify(move)}`);
        }
      }
      if (this.isCheck() && moveObj.flags & BITS.NULL_MOVE) {
        throw new Error("Null move not allowed when in check");
      }
      const prettyMove = new Move(this, moveObj);
      this._makeMove(moveObj);
      this._incPositionCount();
      return prettyMove;
    }
    _push(move) {
      this._history.push({
        move,
        kings: { b: this._kings.b, w: this._kings.w },
        turn: this._turn,
        castling: { b: this._castling.b, w: this._castling.w },
        epSquare: this._epSquare,
        halfMoves: this._halfMoves,
        moveNumber: this._moveNumber
      });
    }
    _movePiece(from, to) {
      this._hash ^= this._pieceKey(from);
      this._board[to] = this._board[from];
      delete this._board[from];
      this._hash ^= this._pieceKey(to);
    }
    _makeMove(move) {
      const us = this._turn;
      const them = swapColor(us);
      this._push(move);
      if (move.flags & BITS.NULL_MOVE) {
        if (us === BLACK) {
          this._moveNumber++;
        }
        this._halfMoves++;
        this._turn = them;
        this._epSquare = EMPTY;
        return;
      }
      this._hash ^= this._epKey();
      this._hash ^= this._castlingKey();
      if (move.captured) {
        this._hash ^= this._pieceKey(move.to);
      }
      this._movePiece(move.from, move.to);
      if (move.flags & BITS.EP_CAPTURE) {
        if (this._turn === BLACK) {
          this._clear(move.to - 16);
        } else {
          this._clear(move.to + 16);
        }
      }
      if (move.promotion) {
        this._clear(move.to);
        this._set(move.to, { type: move.promotion, color: us });
      }
      if (this._board[move.to].type === KING) {
        this._kings[us] = move.to;
        if (move.flags & BITS.KSIDE_CASTLE) {
          const castlingTo = move.to - 1;
          const castlingFrom = move.to + 1;
          this._movePiece(castlingFrom, castlingTo);
        } else if (move.flags & BITS.QSIDE_CASTLE) {
          const castlingTo = move.to + 1;
          const castlingFrom = move.to - 2;
          this._movePiece(castlingFrom, castlingTo);
        }
        this._castling[us] = 0;
      }
      if (this._castling[us]) {
        for (let i = 0, len = ROOKS[us].length; i < len; i++) {
          if (move.from === ROOKS[us][i].square && this._castling[us] & ROOKS[us][i].flag) {
            this._castling[us] ^= ROOKS[us][i].flag;
            break;
          }
        }
      }
      if (this._castling[them]) {
        for (let i = 0, len = ROOKS[them].length; i < len; i++) {
          if (move.to === ROOKS[them][i].square && this._castling[them] & ROOKS[them][i].flag) {
            this._castling[them] ^= ROOKS[them][i].flag;
            break;
          }
        }
      }
      this._hash ^= this._castlingKey();
      if (move.flags & BITS.BIG_PAWN) {
        let epSquare;
        if (us === BLACK) {
          epSquare = move.to - 16;
        } else {
          epSquare = move.to + 16;
        }
        if (!(move.to - 1 & 136) && this._board[move.to - 1]?.type === PAWN && this._board[move.to - 1]?.color === them || !(move.to + 1 & 136) && this._board[move.to + 1]?.type === PAWN && this._board[move.to + 1]?.color === them) {
          this._epSquare = epSquare;
          this._hash ^= this._epKey();
        } else {
          this._epSquare = EMPTY;
        }
      } else {
        this._epSquare = EMPTY;
      }
      if (move.piece === PAWN) {
        this._halfMoves = 0;
      } else if (move.flags & (BITS.CAPTURE | BITS.EP_CAPTURE)) {
        this._halfMoves = 0;
      } else {
        this._halfMoves++;
      }
      if (us === BLACK) {
        this._moveNumber++;
      }
      this._turn = them;
      this._hash ^= SIDE_KEY;
    }
    undo() {
      const hash = this._hash;
      const move = this._undoMove();
      if (move) {
        const prettyMove = new Move(this, move);
        this._decPositionCount(hash);
        return prettyMove;
      }
      return null;
    }
    _undoMove() {
      const old = this._history.pop();
      if (old === void 0) {
        return null;
      }
      this._hash ^= this._epKey();
      this._hash ^= this._castlingKey();
      const move = old.move;
      this._kings = old.kings;
      this._turn = old.turn;
      this._castling = old.castling;
      this._epSquare = old.epSquare;
      this._halfMoves = old.halfMoves;
      this._moveNumber = old.moveNumber;
      this._hash ^= this._epKey();
      this._hash ^= this._castlingKey();
      this._hash ^= SIDE_KEY;
      const us = this._turn;
      const them = swapColor(us);
      if (move.flags & BITS.NULL_MOVE) {
        return move;
      }
      this._movePiece(move.to, move.from);
      if (move.piece) {
        this._clear(move.from);
        this._set(move.from, { type: move.piece, color: us });
      }
      if (move.captured) {
        if (move.flags & BITS.EP_CAPTURE) {
          let index;
          if (us === BLACK) {
            index = move.to - 16;
          } else {
            index = move.to + 16;
          }
          this._set(index, { type: PAWN, color: them });
        } else {
          this._set(move.to, { type: move.captured, color: them });
        }
      }
      if (move.flags & (BITS.KSIDE_CASTLE | BITS.QSIDE_CASTLE)) {
        let castlingTo, castlingFrom;
        if (move.flags & BITS.KSIDE_CASTLE) {
          castlingTo = move.to + 1;
          castlingFrom = move.to - 1;
        } else {
          castlingTo = move.to - 2;
          castlingFrom = move.to + 1;
        }
        this._movePiece(castlingFrom, castlingTo);
      }
      return move;
    }
    pgn({ newline = "\n", maxWidth = 0 } = {}) {
      const result = [];
      let headerExists = false;
      for (const i in this._header) {
        const headerTag = this._header[i];
        if (headerTag)
          result.push(`[${i} "${this._header[i]}"]` + newline);
        headerExists = true;
      }
      if (headerExists && this._history.length) {
        result.push(newline);
      }
      const appendComment = (moveString2) => {
        const comment = this._comments[this.fen()];
        if (typeof comment !== "undefined") {
          const delimiter = moveString2.length > 0 ? " " : "";
          moveString2 = `${moveString2}${delimiter}{${comment}}`;
        }
        return moveString2;
      };
      const reversedHistory = [];
      while (this._history.length > 0) {
        reversedHistory.push(this._undoMove());
      }
      const moves = [];
      let moveString = "";
      if (reversedHistory.length === 0) {
        moves.push(appendComment(""));
      }
      while (reversedHistory.length > 0) {
        moveString = appendComment(moveString);
        const move = reversedHistory.pop();
        if (!move) {
          break;
        }
        if (!this._history.length && move.color === "b") {
          const prefix = `${this._moveNumber}. ...`;
          moveString = moveString ? `${moveString} ${prefix}` : prefix;
        } else if (move.color === "w") {
          if (moveString.length) {
            moves.push(moveString);
          }
          moveString = this._moveNumber + ".";
        }
        moveString = moveString + " " + this._moveToSan(move, this._moves({ legal: true }));
        this._makeMove(move);
      }
      if (moveString.length) {
        moves.push(appendComment(moveString));
      }
      moves.push(this._header.Result || "*");
      if (maxWidth === 0) {
        return result.join("") + moves.join(" ");
      }
      const strip = function() {
        if (result.length > 0 && result[result.length - 1] === " ") {
          result.pop();
          return true;
        }
        return false;
      };
      const wrapComment = function(width, move) {
        for (const token of move.split(" ")) {
          if (!token) {
            continue;
          }
          if (width + token.length > maxWidth) {
            while (strip()) {
              width--;
            }
            result.push(newline);
            width = 0;
          }
          result.push(token);
          width += token.length;
          result.push(" ");
          width++;
        }
        if (strip()) {
          width--;
        }
        return width;
      };
      let currentWidth = 0;
      for (let i = 0; i < moves.length; i++) {
        if (currentWidth + moves[i].length > maxWidth) {
          if (moves[i].includes("{")) {
            currentWidth = wrapComment(currentWidth, moves[i]);
            continue;
          }
        }
        if (currentWidth + moves[i].length > maxWidth && i !== 0) {
          if (result[result.length - 1] === " ") {
            result.pop();
          }
          result.push(newline);
          currentWidth = 0;
        } else if (i !== 0) {
          result.push(" ");
          currentWidth++;
        }
        result.push(moves[i]);
        currentWidth += moves[i].length;
      }
      return result.join("");
    }
    /**
     * @deprecated Use `setHeader` and `getHeaders` instead. This method will return null header tags (which is not what you want)
     */
    header(...args) {
      for (let i = 0; i < args.length; i += 2) {
        if (typeof args[i] === "string" && typeof args[i + 1] === "string") {
          this._header[args[i]] = args[i + 1];
        }
      }
      return this._header;
    }
    // TODO: value validation per spec
    setHeader(key2, value2) {
      this._header[key2] = value2 ?? SEVEN_TAG_ROSTER[key2] ?? null;
      return this.getHeaders();
    }
    removeHeader(key2) {
      if (key2 in this._header) {
        this._header[key2] = SEVEN_TAG_ROSTER[key2] || null;
        return true;
      }
      return false;
    }
    // return only non-null headers (omit placemarker nulls)
    getHeaders() {
      const nonNullHeaders = {};
      for (const [key2, value2] of Object.entries(this._header)) {
        if (value2 !== null) {
          nonNullHeaders[key2] = value2;
        }
      }
      return nonNullHeaders;
    }
    loadPgn(pgn2, { strict = false, newlineChar = "\r?\n" } = {}) {
      if (newlineChar !== "\r?\n") {
        pgn2 = pgn2.replace(new RegExp(newlineChar, "g"), "\n");
      }
      const parsedPgn = peg$parse(pgn2);
      this.reset();
      const headers = parsedPgn.headers;
      let fen = "";
      for (const key2 in headers) {
        if (key2.toLowerCase() === "fen") {
          fen = headers[key2];
        }
        this.header(key2, headers[key2]);
      }
      if (!strict) {
        if (fen) {
          this.load(fen, { preserveHeaders: true });
        }
      } else {
        if (headers["SetUp"] === "1") {
          if (!("FEN" in headers)) {
            throw new Error("Invalid PGN: FEN tag must be supplied with SetUp tag");
          }
          this.load(headers["FEN"], { preserveHeaders: true });
        }
      }
      let node2 = parsedPgn.root;
      while (node2) {
        if (node2.move) {
          const move = this._moveFromSan(node2.move, strict);
          if (move == null) {
            throw new Error(`Invalid move in PGN: ${node2.move}`);
          } else {
            this._makeMove(move);
            this._incPositionCount();
          }
        }
        if (node2.comment !== void 0) {
          this._comments[this.fen()] = node2.comment;
        }
        node2 = node2.variations[0];
      }
      const result = parsedPgn.result;
      if (result && Object.keys(this._header).length && this._header["Result"] !== result) {
        this.setHeader("Result", result);
      }
    }
    /*
     * Convert a move from 0x88 coordinates to Standard Algebraic Notation
     * (SAN)
     *
     * @param {boolean} strict Use the strict SAN parser. It will throw errors
     * on overly disambiguated moves (see below):
     *
     * r1bqkbnr/ppp2ppp/2n5/1B1pP3/4P3/8/PPPP2PP/RNBQK1NR b KQkq - 2 4
     * 4. ... Nge7 is overly disambiguated because the knight on c6 is pinned
     * 4. ... Ne7 is technically the valid SAN
     */
    _moveToSan(move, moves) {
      let output = "";
      if (move.flags & BITS.KSIDE_CASTLE) {
        output = "O-O";
      } else if (move.flags & BITS.QSIDE_CASTLE) {
        output = "O-O-O";
      } else if (move.flags & BITS.NULL_MOVE) {
        return SAN_NULLMOVE;
      } else {
        if (move.piece !== PAWN) {
          const disambiguator = getDisambiguator(move, moves);
          output += move.piece.toUpperCase() + disambiguator;
        }
        if (move.flags & (BITS.CAPTURE | BITS.EP_CAPTURE)) {
          if (move.piece === PAWN) {
            output += algebraic(move.from)[0];
          }
          output += "x";
        }
        output += algebraic(move.to);
        if (move.promotion) {
          output += "=" + move.promotion.toUpperCase();
        }
      }
      this._makeMove(move);
      if (this.isCheck()) {
        if (this.isCheckmate()) {
          output += "#";
        } else {
          output += "+";
        }
      }
      this._undoMove();
      return output;
    }
    // convert a move from Standard Algebraic Notation (SAN) to 0x88 coordinates
    _moveFromSan(move, strict = false) {
      let cleanMove = strippedSan(move);
      if (!strict) {
        if (cleanMove === "0-0") {
          cleanMove = "O-O";
        } else if (cleanMove === "0-0-0") {
          cleanMove = "O-O-O";
        }
      }
      if (cleanMove == SAN_NULLMOVE) {
        const res = {
          color: this._turn,
          from: 0,
          to: 0,
          piece: "k",
          flags: BITS.NULL_MOVE
        };
        return res;
      }
      let pieceType = inferPieceType(cleanMove);
      let moves = this._moves({ legal: true, piece: pieceType });
      for (let i = 0, len = moves.length; i < len; i++) {
        if (cleanMove === strippedSan(this._moveToSan(moves[i], moves))) {
          return moves[i];
        }
      }
      if (strict) {
        return null;
      }
      let piece = void 0;
      let matches = void 0;
      let from = void 0;
      let to = void 0;
      let promotion = void 0;
      let overlyDisambiguated = false;
      matches = cleanMove.match(/([pnbrqkPNBRQK])?([a-h][1-8])x?-?([a-h][1-8])([qrbnQRBN])?/);
      if (matches) {
        piece = matches[1];
        from = matches[2];
        to = matches[3];
        promotion = matches[4];
        if (from.length == 1) {
          overlyDisambiguated = true;
        }
      } else {
        matches = cleanMove.match(/([pnbrqkPNBRQK])?([a-h]?[1-8]?)x?-?([a-h][1-8])([qrbnQRBN])?/);
        if (matches) {
          piece = matches[1];
          from = matches[2];
          to = matches[3];
          promotion = matches[4];
          if (from.length == 1) {
            overlyDisambiguated = true;
          }
        }
      }
      pieceType = inferPieceType(cleanMove);
      moves = this._moves({
        legal: true,
        piece: piece ? piece : pieceType
      });
      if (!to) {
        return null;
      }
      for (let i = 0, len = moves.length; i < len; i++) {
        if (!from) {
          if (cleanMove === strippedSan(this._moveToSan(moves[i], moves)).replace("x", "")) {
            return moves[i];
          }
        } else if ((!piece || piece.toLowerCase() == moves[i].piece) && Ox88[from] == moves[i].from && Ox88[to] == moves[i].to && (!promotion || promotion.toLowerCase() == moves[i].promotion)) {
          return moves[i];
        } else if (overlyDisambiguated) {
          const square = algebraic(moves[i].from);
          if ((!piece || piece.toLowerCase() == moves[i].piece) && Ox88[to] == moves[i].to && (from == square[0] || from == square[1]) && (!promotion || promotion.toLowerCase() == moves[i].promotion)) {
            return moves[i];
          }
        }
      }
      return null;
    }
    ascii() {
      let s = "   +------------------------+\n";
      for (let i = Ox88.a8; i <= Ox88.h1; i++) {
        if (file(i) === 0) {
          s += " " + "87654321"[rank(i)] + " |";
        }
        if (this._board[i]) {
          const piece = this._board[i].type;
          const color = this._board[i].color;
          const symbol = color === WHITE ? piece.toUpperCase() : piece.toLowerCase();
          s += " " + symbol + " ";
        } else {
          s += " . ";
        }
        if (i + 1 & 136) {
          s += "|\n";
          i += 8;
        }
      }
      s += "   +------------------------+\n";
      s += "     a  b  c  d  e  f  g  h";
      return s;
    }
    perft(depth2) {
      const moves = this._moves({ legal: false });
      let nodes = 0;
      const color = this._turn;
      for (let i = 0, len = moves.length; i < len; i++) {
        this._makeMove(moves[i]);
        if (!this._isKingAttacked(color)) {
          if (depth2 - 1 > 0) {
            nodes += this.perft(depth2 - 1);
          } else {
            nodes++;
          }
        }
        this._undoMove();
      }
      return nodes;
    }
    setTurn(color) {
      if (this._turn == color) {
        return false;
      }
      this.move("--");
      return true;
    }
    turn() {
      return this._turn;
    }
    board() {
      const output = [];
      let row = [];
      for (let i = Ox88.a8; i <= Ox88.h1; i++) {
        if (this._board[i] == null) {
          row.push(null);
        } else {
          row.push({
            square: algebraic(i),
            type: this._board[i].type,
            color: this._board[i].color
          });
        }
        if (i + 1 & 136) {
          output.push(row);
          row = [];
          i += 8;
        }
      }
      return output;
    }
    squareColor(square) {
      if (square in Ox88) {
        const sq = Ox88[square];
        return (rank(sq) + file(sq)) % 2 === 0 ? "light" : "dark";
      }
      return null;
    }
    history({ verbose = false } = {}) {
      const reversedHistory = [];
      const moveHistory = [];
      while (this._history.length > 0) {
        reversedHistory.push(this._undoMove());
      }
      while (true) {
        const move = reversedHistory.pop();
        if (!move) {
          break;
        }
        if (verbose) {
          moveHistory.push(new Move(this, move));
        } else {
          moveHistory.push(this._moveToSan(move, this._moves()));
        }
        this._makeMove(move);
      }
      return moveHistory;
    }
    /*
     * Keeps track of position occurrence counts for the purpose of repetition
     * checking. Old positions are removed from the map if their counts are reduced to 0.
     */
    _getPositionCount(hash) {
      return this._positionCount.get(hash) ?? 0;
    }
    _incPositionCount() {
      this._positionCount.set(this._hash, (this._positionCount.get(this._hash) ?? 0) + 1);
    }
    _decPositionCount(hash) {
      const currentCount = this._positionCount.get(hash) ?? 0;
      if (currentCount === 1) {
        this._positionCount.delete(hash);
      } else {
        this._positionCount.set(hash, currentCount - 1);
      }
    }
    _pruneComments() {
      const reversedHistory = [];
      const currentComments = {};
      const copyComment = (fen) => {
        if (fen in this._comments) {
          currentComments[fen] = this._comments[fen];
        }
      };
      while (this._history.length > 0) {
        reversedHistory.push(this._undoMove());
      }
      copyComment(this.fen());
      while (true) {
        const move = reversedHistory.pop();
        if (!move) {
          break;
        }
        this._makeMove(move);
        copyComment(this.fen());
      }
      this._comments = currentComments;
    }
    getComment() {
      return this._comments[this.fen()];
    }
    setComment(comment) {
      this._comments[this.fen()] = comment.replace("{", "[").replace("}", "]");
    }
    /**
     * @deprecated Renamed to `removeComment` for consistency
     */
    deleteComment() {
      return this.removeComment();
    }
    removeComment() {
      const comment = this._comments[this.fen()];
      delete this._comments[this.fen()];
      return comment;
    }
    getComments() {
      this._pruneComments();
      return Object.keys(this._comments).map((fen) => {
        return { fen, comment: this._comments[fen] };
      });
    }
    /**
     * @deprecated Renamed to `removeComments` for consistency
     */
    deleteComments() {
      return this.removeComments();
    }
    removeComments() {
      this._pruneComments();
      return Object.keys(this._comments).map((fen) => {
        const comment = this._comments[fen];
        delete this._comments[fen];
        return { fen, comment };
      });
    }
    setCastlingRights(color, rights) {
      for (const side of [KING, QUEEN]) {
        if (rights[side] !== void 0) {
          if (rights[side]) {
            this._castling[color] |= SIDES[side];
          } else {
            this._castling[color] &= ~SIDES[side];
          }
        }
      }
      this._updateCastlingRights();
      const result = this.getCastlingRights(color);
      return (rights[KING] === void 0 || rights[KING] === result[KING]) && (rights[QUEEN] === void 0 || rights[QUEEN] === result[QUEEN]);
    }
    getCastlingRights(color) {
      return {
        [KING]: (this._castling[color] & SIDES[KING]) !== 0,
        [QUEEN]: (this._castling[color] & SIDES[QUEEN]) !== 0
      };
    }
    moveNumber() {
      return this._moveNumber;
    }
  };

  // src/position.ts
  var START = DEFAULT_POSITION;
  function allowedPage(path) {
    return /^\/(?:[a-z]{2}(?:-[a-z]{2})?\/)?(?:play|analysis|live|game)(?:\/|$)/i.test(path);
  }
  function validFen(fen) {
    if (typeof fen !== "string" || fen.length > 160 || fen.trim().split(/\s+/).length !== 6) return null;
    try {
      const c = new Chess(fen);
      for (const [right, king, rook] of [["K", "e1", "h1"], ["Q", "e1", "a1"], ["k", "e8", "h8"], ["q", "e8", "a8"]]) {
        if (!fen.split(" ")[2].includes(right)) continue;
        const color = right === right.toUpperCase() ? "w" : "b";
        if (c.get(king)?.type !== "k" || c.get(king)?.color !== color || c.get(rook)?.type !== "r" || c.get(rook)?.color !== color) return null;
      }
      const other = fen.split(" ");
      other[1] = other[1] === "w" ? "b" : "w";
      other[3] = "-";
      if (new Chess(other.join(" ")).isCheck()) return null;
      return c.fen();
    } catch {
      return null;
    }
  }
  function placement(pieces2) {
    const rows = [];
    for (let rank3 = 8; rank3 >= 1; rank3--) {
      let row = "", empty = 0;
      for (let file3 = 0; file3 < 8; file3++) {
        const p = pieces2.get(`${"abcdefgh"[file3]}${rank3}`);
        if (!p) {
          empty++;
          continue;
        }
        if (!/^[wb][prnbqk]$/.test(p)) return null;
        if (empty) row += empty;
        empty = 0;
        row += p[0] === "w" ? p[1].toUpperCase() : p[1];
      }
      if (empty) row += empty;
      rows.push(row);
    }
    return rows.join("/");
  }
  function squareBox(square, flipped2) {
    const f = square.charCodeAt(0) - 97, r = Number(square[1]) - 1;
    return { x: (flipped2 ? 7 - f : f) * 12.5, y: (flipped2 ? r : 7 - r) * 12.5 };
  }
  function legalPV(fen, moves) {
    const c = new Chess(fen);
    const result = [];
    for (const uci of moves.slice(0, 16)) {
      if (!/^[a-h][1-8][a-h][1-8][qrbn]?$/.test(uci)) break;
      try {
        const m = c.move({ from: uci.slice(0, 2), to: uci.slice(2, 4), promotion: uci[4] });
        result.push({ uci, san: m.san });
      } catch {
        break;
      }
    }
    return result;
  }
  var PositionTracker = class {
    chess = null;
    rejected = "";
    reset() {
      this.chess = null;
      this.rejected = "";
    }
    accept(fen) {
      const valid = validFen(fen);
      if (!valid) return false;
      this.chess = new Chess(valid);
      this.rejected = "";
      return true;
    }
    sync(board2) {
      if (!this.chess && board2 === START.split(" ")[0]) {
        this.chess = new Chess();
        return this.chess.fen();
      }
      if (!this.chess) return null;
      if (this.chess.fen().split(" ")[0] === board2) return this.chess.fen();
      const key2 = this.chess.fen() + "|" + board2;
      if (this.rejected === key2) return null;
      const c = this.chess;
      let visited = 0;
      for (let depth2 = 1; depth2 <= 2; depth2++) {
        const matches = /* @__PURE__ */ new Map();
        const search = (left, path) => {
          if (++visited > 5e3) return;
          if (!left) {
            if (c.fen().split(" ")[0] === board2) matches.set(c.fen(), path);
            return;
          }
          for (const m of c.moves({ verbose: true })) {
            c.move(m);
            search(left - 1, [...path, m.san]);
            c.undo();
          }
        };
        search(depth2, []);
        if (matches.size === 1) {
          for (const san of [...matches.values()][0]) c.move(san);
          return c.fen();
        }
        if (matches.size > 1 || visited > 5e3) {
          this.rejected = key2;
          return null;
        }
      }
      if (board2 === START.split(" ")[0]) {
        this.chess = new Chess();
        return this.chess.fen();
      }
      this.rejected = key2;
      return null;
    }
  };

  // src/vision.ts
  var CODES = ["wp", "wn", "wb", "wr", "wq", "wk", "bp", "bn", "bb", "br", "bq", "bk"];
  function classifyPixels(sample, templates) {
    const scores = [...templates].filter(([, t]) => t.length === sample.length).map(([code, t]) => {
      let error = 0, weight = 0;
      for (let i = 0; i < t.length; i += 4) {
        const a = Math.max(sample[i + 3], t[i + 3]) / 255;
        if (a < 0.03) continue;
        for (let c = 0; c < 3; c++) error += Math.abs(sample[i + c] - t[i + c]) * a;
        error += Math.abs(sample[i + 3] - t[i + 3]);
        weight += 255 * (3 * a + 1);
      }
      return { code, score: weight ? 1 - error / weight : 0 };
    }).sort((a, b) => b.score - a.score);
    return scores.length === 12 && scores[0].score > 0.96 && scores[0].score - scores[1].score > 0.012 ? scores[0].code : null;
  }
  var cache = /* @__PURE__ */ new Map();
  var banks = /* @__PURE__ */ new Map();
  var pending = /* @__PURE__ */ new Set();
  function assetUrl(el2) {
    const raw = el2.getAttribute("src") || getComputedStyle(el2).backgroundImage.match(/url\(["']?(.*?)["']?\)/)?.[1];
    if (!raw) return null;
    try {
      const u = new URL(raw, location.href);
      return ["data:", "blob:"].includes(u.protocol) || u.protocol === "https:" && u.hostname === "images.chesscomfiles.com" ? u.href : null;
    } catch {
      return null;
    }
  }
  function pixels(url) {
    return new Promise((resolve, reject) => {
      const img = new Image();
      img.crossOrigin = "anonymous";
      const timer = setTimeout(() => reject(Error("Image timeout")), 5e3);
      img.onload = () => {
        clearTimeout(timer);
        try {
          const canvas = document.createElement("canvas");
          canvas.width = canvas.height = 32;
          const ctx = canvas.getContext("2d", { willReadFrequently: true });
          ctx.drawImage(img, 0, 0, 32, 32);
          resolve(ctx.getImageData(0, 0, 32, 32).data);
        } catch (e) {
          reject(e);
        }
      };
      img.onerror = () => {
        clearTimeout(timer);
        reject(Error("Unreadable image"));
      };
      img.src = url;
    });
  }
  function cachedVisualCode(el2) {
    const url = assetUrl(el2);
    return url ? cache.get(url) ?? null : null;
  }
  function prepareVision(board2, onReady) {
    const nodes = [...board2.querySelectorAll('.piece, img[data-square], img[class*="square-"]')];
    const theme = nodes.map((n) => assetUrl(n)?.match(/\/chess-themes\/pieces\/([a-z0-9_-]+)\//i)?.[1]).find(Boolean) ?? "neo";
    for (const node2 of nodes) {
      if (/\b[wb][prnbqk]\b/.test(node2.className) || /^[wb][prnbqk]$/.test(node2.getAttribute("data-piece") ?? "")) continue;
      const url = assetUrl(node2);
      if (!url || /\/[wb][prnbqk]\.(png|svg|webp)/i.test(url) || cache.has(url) || pending.has(url)) continue;
      if (cache.size > 256) cache.clear();
      pending.add(url);
      if (!banks.has(theme)) banks.set(theme, Promise.all(CODES.map(async (code) => [code, await pixels(`https://images.chesscomfiles.com/chess-themes/pieces/${theme}/150/${code}.png`)])).then((x) => new Map(x)));
      Promise.all([pixels(url), banks.get(theme)]).then(([sample, templates]) => cache.set(url, classifyPixels(sample, templates))).catch(() => cache.set(url, null)).finally(() => {
        pending.delete(url);
        onReady();
      });
    }
  }

  // src/detection.ts
  var BOARD_SELECTOR = "wc-chess-board, chess-board, .board-layout-chessboard .board, #board-single";
  function findBoard(root = document) {
    return [...root.querySelectorAll(BOARD_SELECTOR)].filter((b) => {
      const r = b.getBoundingClientRect();
      return r.width > 120 && r.height > 120 && Math.abs(r.width - r.height) < r.width * 0.08;
    }).sort((a, b) => b.getBoundingClientRect().width - a.getBoundingClientRect().width)[0] ?? null;
  }
  function pieceCode(el2) {
    const cls = el2.getAttribute("class") ?? "";
    const token = cls.match(/(?:^|\s)([wb][prnbqk])(?:\s|$)/)?.[1];
    if (token) return token;
    const data = el2.getAttribute("data-piece");
    if (data && /^[wb][prnbqk]$/.test(data)) return data;
    const src = (el2.getAttribute("src") ?? "") + " " + (el2.getAttribute("style") ?? "") + " " + getComputedStyle(el2).backgroundImage;
    return src.match(/[/\s]([wb][prnbqk])\.(?:png|svg|webp)/i)?.[1]?.toLowerCase() ?? cachedVisualCode(el2);
  }
  function readBoard(board2) {
    const pieces2 = /* @__PURE__ */ new Map();
    let bad = false;
    for (const el2 of board2.querySelectorAll(".piece, [data-piece], img")) {
      if (el2.classList.contains("ghost") || el2.classList.contains("dragging")) {
        bad = true;
        continue;
      }
      const code = pieceCode(el2);
      if (!code) {
        if (el2.matches('.piece, [data-piece], [data-square], [class*="square-"]')) bad = true;
        continue;
      }
      const n = el2.getAttribute("class")?.match(/\bsquare-([1-8])([1-8])\b/);
      const square = n ? `${"abcdefgh"[Number(n[1]) - 1]}${n[2]}` : el2.getAttribute("data-square");
      if (!square || !/^[a-h][1-8]$/.test(square) || pieces2.has(square)) {
        bad = true;
        continue;
      }
      pieces2.set(square, code);
    }
    return { placement: bad || pieces2.size < 2 ? null : placement(pieces2), flipped: board2.classList.contains("flipped") || board2.getAttribute("data-flipped") === "true" || board2.getAttribute("orientation") === "black" };
  }

  // src/uci.ts
  var MultiPV = class {
    constructor(count) {
      this.count = count;
    }
    count;
    batches = /* @__PURE__ */ new Map();
    published = 0;
    push(line) {
      if (line.bound || line.rank < 1 || line.rank > this.count || line.depth < this.published) return null;
      const batch = this.batches.get(line.depth) ?? /* @__PURE__ */ new Map();
      batch.set(line.rank, line);
      this.batches.set(line.depth, batch);
      if (batch.size !== this.count || new Set([...batch.values()].map((l) => l.pv[0])).size !== this.count) return null;
      this.published = line.depth;
      for (const d of this.batches.keys()) if (d < line.depth) this.batches.delete(d);
      return [...batch.values()].sort((a, b) => a.rank - b.rank);
    }
  };
  function parseInfo(text) {
    if (!text.startsWith("info ") || !text.includes(" pv ")) return null;
    const depth2 = Number(text.match(/\bdepth (\d+)/)?.[1]);
    const score = text.match(/\bscore (cp|mate) (-?\d+)/);
    const pv = text.split(" pv ")[1].trim().split(/\s+/);
    if (!depth2 || !score || !pv.length) return null;
    return { rank: Number(text.match(/\bmultipv (\d+)/)?.[1] ?? 1), depth: depth2, ...score[1] === "cp" ? { cp: Number(score[2]) } : { mate: Number(score[2]) }, pv, bound: /\b(?:lowerbound|upperbound)\b/.test(text) };
  }
  function scoreLabel(line, turn) {
    const sign = turn === "w" ? 1 : -1;
    if (line.mate !== void 0) return `Mate ${line.mate * sign > 0 ? "+" : ""}${line.mate * sign}`;
    const val = (line.cp ?? 0) * sign / 100;
    return `${val >= 0 ? "+" : ""}${val.toFixed(2)}`;
  }

  // src/modes.ts
  var MODES = {
    noob: { label: "Noob", skill: 0, maxDepth: 6, time: 1e3, description: "Beginner strength \xB7 intentional weaker choices" },
    intermediate: { label: "Intermediate", skill: 8, maxDepth: 10, time: 2500, description: "Balanced strength \xB7 occasional inaccuracies" },
    pro: { label: "Pro", skill: 16, maxDepth: 18, time: 6e3, description: "Strong play \xB7 optional sound-sacrifice hunt" },
    hacker: { label: "Hacker", skill: 20, maxDepth: 24, time: 8e3, description: "Maximum lite-engine strength" },
    magnus: { label: "Magnus Carlsen", skill: 20, maxDepth: 30, time: 2e4, description: "Full NNUE model \xB7 extended elite analysis" },
    witty: { label: "Witty Alien", skill: 20, maxDepth: 24, time: 1e4, description: "Recorded games \xB7 learned move preferences" },
    stealth: { label: "Stealth (Undetectable)", skill: 20, maxDepth: 22, time: 5e3, description: "Human-like play \xB7 anti-detection \xB7 varied move choices" },
    trap: { label: "Trap Master", skill: 20, maxDepth: 20, time: 4e3, description: "Trappy moves \xB7 practical complications \xB7 hard to defend" },
    practical: { label: "Practical Play", skill: 20, maxDepth: 22, time: 6e3, description: "Maximize winning chances \xB7 forcing moves \xB7 time pressure" },
    alien: { label: "Alien Gambit \uD83D\uDC7D", skill: 20, maxDepth: 24, time: 8e3, description: "Forces Alien Gambit as White (1.e4 \u2192 Nxf7 knight sac on f7) \xB7 Caro-Kann trap" }
  };
  function paceId(value2) {
    return value2 === "instant" || value2 === "quick" || value2 === "deep" ? value2 : "balanced";
  }
  function modeId(value2) {
    return typeof value2 === "string" && Object.hasOwn(MODES, value2) ? value2 : "hacker";
  }
  function engineVariant(mode2) {
    return mode2 === "magnus" || mode2 === "witty" ? "full" : "lite";
  }
  function searchSettings(mode2, depth2, pace2 = "balanced") {
    const p = MODES[mode2], target = Math.max(1, Math.min(p.maxDepth, (Math.floor(depth2) || 16) + (mode2 === "magnus" ? 4 : mode2 === "witty" ? 2 : 0)));
    const depthCap = pace2 === "instant" ? Math.min(target, 10) : pace2 === "quick" ? Math.min(target, 12) : pace2 === "deep" ? Math.min(p.maxDepth, target + 2) : target;
    const timeCap = pace2 === "instant" ? Math.min(p.time, 800) : pace2 === "quick" ? Math.min(p.time, 1500) : pace2 === "deep" ? Math.min(p.time * 2, 3e4) : p.time;
    return { ...p, depth: depthCap, time: timeCap, hash: engineVariant(mode2) === "full" ? 64 : 32 };
  }

  // src/alien-book.ts — expanded with all major deviations
  function key(c) {
    return c.fen().split(" ").slice(0, 4).join(" ");
  }
  var book = /* @__PURE__ */ new Map();
  function addLine(moves, notes) {
    try {
      var c = new Chess();
      for (var i = 0; i < moves.length; i++) {
        var before = key(c), isWhite = c.turn() === "w";
        var mv = c.move(moves[i]);
        if (!mv) break;
        if (isWhite && !book.has(before)) {
          book.set(before, {
            move: mv.from + mv.to + (mv.promotion || ""),
            san: mv.san,
            note: "\uD83D\uDC7D Alien Gambit \xB7 " + (notes[mv.san] || "Alien Gambit repertoire \xB7 " + mv.san)
          });
        }
      }
    } catch(e) {}
  }
  var N = {
    "e4":  "1.e4 — steering for Caro-Kann or French",
    "d4":  "d4 — building the center",
    "Nc3": "Nc3 — developing, preparing Nxe4",
    "Nd2": "Nd2 — alternative development",
    "Nxe4":"Nxe4 — recapture, now Nf6 Ng5!",
    "Ng5": "Ng5!! — the Alien move, threatening f7",
    "Nxf7":"Nxf7!! — the ALIEN GAMBIT! knight sacrifice on f7!",
    "Nf3": "Nf3 — attack the exposed king",
    "Bc4": "Bc4 — bishop eyes f7 and e6",
    "Qe2": "Qe2 — pressure on e6, connecting rooks",
    "Qf3": "Qf3 — attack f7 from afar",
    "Qh5+":"Qh5+ — check, winning material",
    "d5":  "d5 — central counter",
    "Ng5": "Ng5 — going for f7 anyway"
  };
  // MAIN LINE: 1.e4 c6 2.d4 d5 3.Nc3 dxe4 4.Nxe4 Nf6 5.Ng5 h6 6.Nxf7 Kxf7 7.Nf3
  addLine(["e4","c6","d4","d5","Nc3","dxe4","Nxe4","Nf6","Ng5","h6","Nxf7","Kxf7","Nf3"], N);
  // Nc3 development variation
  addLine(["e4","c6","d4","d5","Nd2","dxe4","Nxe4","Nf6","Ng5","h6","Nxf7","Kxf7","Nf3"], N);
  // DEVIATION: Black plays e6 instead of h6 (most common refutation attempt)
  // 5...e6 → 6.Nxf7! anyway
  addLine(["e4","c6","d4","d5","Nc3","dxe4","Nxe4","Nf6","Ng5","e6","Nxf7","Kxf7","Qf3+"], {
    "Nxf7":"Nxf7!! — still the Alien Gambit! e6 doesn't stop it",
    "Qf3+":"Qf3+ — check, attack the king",
    "e4":"1.e4","d4":"d4","Nc3":"Nc3","Nxe4":"Nxe4","Ng5":"Ng5!! — threatening f7"
  });
  // DEVIATION: Black skips h6, plays Bf5 instead
  addLine(["e4","c6","d4","d5","Nc3","dxe4","Nxe4","Nf6","Ng5","Bf5","Nxf7","Kxf7","Qf3+"], {
    "Nxf7":"Nxf7!! — Alien Gambit regardless of Bf5",
    "Qf3+":"Qf3+ — hunting the king",
    "e4":"1.e4","d4":"d4","Nc3":"Nc3","Nxe4":"Nxe4","Ng5":"Ng5!! — threatening f7"
  });
  // DEVIATION: Black plays Nd7 instead of Nf6 (avoids the whole line)
  // → Bc4 threatening f7 anyway
  addLine(["e4","c6","d4","d5","Nc3","dxe4","Nxe4","Nd7","Bc4","Ngf6","Ng5","h6","Nxf7","Kxf7","Qf3+"], {
    "Bc4":"Bc4 — bishop to f7 threat, Alien spirit continues",
    "Ng5":"Ng5 — back to the gambit plan",
    "Nxf7":"Nxf7!! — Alien Gambit!",
    "Qf3+":"Qf3+ — press the king",
    "e4":"1.e4","d4":"d4","Nc3":"Nc3","Nxe4":"Nxe4"
  });
  // DEVIATION: Black doesn't play dxe4, plays e6 on move 3 (entering French-like)
  addLine(["e4","c6","d4","d5","Nc3","e6","Nf3","Nf6","Bd3","Be7","O-O","O-O"], {
    "Nf3":"Nf3 — solid development when Black avoids the gambit",
    "Bd3":"Bd3 — standard setup",
    "O-O":"Castling — good position",
    "e4":"1.e4","d4":"d4","Nc3":"Nc3"
  });
  // BONJOUR VARIATION: Alien Gambit vs French Defense
  // 1.e4 e6 2.d4 d5 3.Nc3 dxe4 4.Nxe4 Nf6 5.Ng5 h6 6.Nxf7!
  addLine(["e4","e6","d4","d5","Nc3","dxe4","Nxe4","Nf6","Ng5","h6","Nxf7","Kxf7","Qf3+"], {
    "Nxf7":"Nxf7!! — ALIEN GAMBIT BONJOUR! French Defense variation",
    "Qf3+":"Qf3+ — hunting the king",
    "e4":"1.e4","d4":"d4","Nc3":"Nc3","Nxe4":"Nxe4","Ng5":"Ng5!! — Bonjour variation"
  });
  // BONJOUR: Black plays e5 instead of h6
  addLine(["e4","e6","d4","d5","Nc3","dxe4","Nxe4","Nf6","Ng5","e5","Nxf7","Kxf7","Qf3+"], {
    "Nxf7":"Nxf7!! — Alien Gambit Bonjour, e5 doesn't stop it",
    "Qf3+":"Qf3+",
    "e4":"1.e4","d4":"d4","Nc3":"Nc3","Nxe4":"Nxe4","Ng5":"Ng5!!"
  });
  function alienBookMove(fen) {
    try {
      const c = new Chess(fen), entry = book.get(key(c));
      if (!entry || c.turn() !== "w") return null;
      const legal = c.move({ from: entry.move.slice(0, 2), to: entry.move.slice(2, 4), promotion: entry.move[4] });
      return legal ? entry : null;
    } catch {
      return null;
    }
  }

  // src/data/witty-model.json
  var witty_model_default = { meta: { username: "witty_alien", generatedAt: "2026-11-04T05:06:15.244Z", sources: ["https://api.chess.com/pub/player/witty_alien/games/2026/11", "https://api.chess.com/pub/player/witty_alien/games/2026/10", "https://api.chess.com/pub/player/witty_alien/games/2026/09"], processedGames: 3488, skippedGames: 512, trainingGames: 3089, heldOutGames: 399, recordedMoves: 109605, uniquePositions: 89959, trainingExamples: 20487, validationSamples: 2603, featureCount: 912, model: "pairwise logistic linear move preference; 4 SGD epochs", dateRange: ["2026-09-14T14:17:45.000Z", "2026-11-03T21:29:40.000Z"], metrics: { top1: 0.32039953899346907, top3: 0.5324625432193623, novelSamples: 1977, novelTop1: 0.23166413758219526, bookCoverage: 0.24049174029965426, bookAgreement: 0.8977635782747604 } }, weights: [-999e-6, 0.758263, 0.149316, -0.39618, -0.028042, -0.405338, -0.173583, 0.519079, -0.098348, -0.015893, -7044e-6, -0.275454, 0.028396, -0.180803, 0.042783, 0.275837, -0.17097, -0.162339, 0.058733, -0.027792, 26e-5, -0.2089, 0.255788, -0.251361, 0.112138, -7119e-6, -0.019645, -0.037598, 0.136573, 0.203882, -0.146255, -0.5188, -0.292756, 0.064403, 0.220147, 0.435619, 0.185226, 0.031538, -0.173156, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1.086043, -0.759606, -0.247828, -0.075374, -1.807275, -0.966671, -1.764446, -1.218906, -0.48129, -0.592443, -0.582205, 0.544818, 2.261399, -0.15876, -0.196773, -0.215005, 0.3449, -0.132308, -0.371434, 0.277634, 0.047346, 0.255051, 0.24023, 0.361373, 0.606723, 0.117656, 0.044602, 0.632831, 0.351604, 0.442357, 0.185149, 0.732742, 0.719273, 0.560555, 0.518732, 0.240888, 0.399894, 0.543405, 0.552504, 0.499876, 0.210652, -0.167461, 0.220939, -0.071706, -0.028539, -0.103764, 0.105686, -0.106136, 0.053907, -1.562614, -0.067069, -0.461154, -0.761672, 0.110133, -0.937816, -0.303901, -0.093033, -0.106608, 0.127521, -0.508574, -0.769092, -0.281177, 0.254022, -0.801619, -1.778858, 0.226732, 0.76731, 0.245311, -2997e-6, 0.883675, 0.206267, -2.413126, -0.672016, -0.238716, -0.28198, 0.923385, 0.899778, 0.400409, 0.026576, -0.263754, 0.127482, 0.187964, 0.473994, 1.019708, 1.298795, 0.656302, 1.352638, -0.070463, -0.102191, -0.202522, 0.233133, 0.144272, 0.251884, 0.348755, 1.571283, -0.014204, -0.295761, -0.197114, 0.330553, 0.081201, -0.132538, 1.885323, -0.656988, -0.750374, -0.080683, -0.077125, 0.050119, 0.086159, -0.011711, 0.215866, -0.113846, -0.295779, 0.49733, 1.011972, -0.496673, -0.044497, -0.349992, -0.313644, 0.016739, -0.245845, 0.770417, 1.509231, 0.746625, -0.484926, -0.400019, 1.254171, 0.672856, -0.087923, 0.715036, 1.662724, 0.641623, 0.841072, 0.063149, 0.357176, 0.547017, -0.158739, 0.019021, -0.04321, 0.663033, 0.209432, 0.047213, -0.050731, -0.520994, 0.242215, -0.121695, -0.580132, 0.132929, -0.182929, 0.316278, -0.382246, 0.05914, -0.356074, -1.039716, -0.417374, -0.65867, 0.196756, -0.018846, -0.545833, 0.317845, -0.255848, -0.371106, -0.360168, -0.977621, -0.780811, -0.614683, -0.517823, 0.434893, -0.8484, -0.299462, -0.499293, -0.292982, -0.154055, 0.058656, -0.307028, -0.449028, -0.207306, 0.283184, 0.125697, 0.287602, 1.249903, 1.575871, 0.234764, 0.464267, 1.132034, -0.382003, -0.349811, 0.110235, -624e-6, -0.318208, -0.543855, -0.066724, -1.005592, 0.09532, 0.393052, 0.038396, -0.141495, -0.167474, -0.319027, 0.712328, 0.220807, 0.020598, -0.733246, -0.13311, -0.653561, -0.208806, -0.659872, -0.646507, -0.141216, -0.564782, -0.080678, -0.393515, -0.670777, -0.608331, -0.584059, -0.481547, -0.014575, -0.073247, -0.24417, -0.537455, 0.288358, -0.183693, -0.272783, -1.036204, -0.056764, 0.01508, 0.403083, 0.419879, 0.32348, 0.163049, 0.157737, -0.360036, 0.387362, 0.993823, 1.156219, 0.471612, 0.403463, 0.108747, -0.205768, 0.126898, 0.42081, 0.734413, -0.444867, -0.456403, -0.986435, -0.253126, 0.033684, 0.524061, 0.128428, -0.030863, 0.194448, 0.458597, 0.667926, 0.511933, 0.586313, 0.116885, 0.559611, 0.212707, 0.430604, 0.370111, 0.113855, 0.095566, 0.684077, 1.311742, 0.544877, 0.111874, -0.869738, 0.200437, 0.291652, 0.291691, 0.220604, -0.146918, 1.12194, -0.154027, -0.251833, -0.569526, -0.553289, 0.078152, -0.488548, -0.210647, 0.647494, -0.228727, -0.494953, -0.733725, 0.076111, -0.322197, -0.480526, -0.08908, 0.812259, -0.341181, -0.101183, -0.22905, -0.976371, -0.29319, -0.272611, -0.544346, 0.104646, -0.11737, 0.168757, -0.488325, -0.519774, -0.20665, -0.536579, -0.53352, 0.074093, 0.506542, 0.349659, 0.115624, -0.987639, -0.862161, -0.464339, -0.456394, 0.449941, -0.077637, 0.144196, -0.617284, -0.869645, -0.607242, -0.267908, -0.231476, -0.081416, 0.027438, 0.535507, 0.018543, 6349e-6, -0.118868, -0.116803, 0.185751, 0.094329, 0.274247, -0.065898, 0.153614, 0.105183, 0.09848, -0.330699, -6044e-6, -0.059897, 0.142644, 0.032783, 0.340152, -0.049815, -0.294561, 0.16843, -0.183418, 0.244165, 0.039319, 0.201838, -0.051831, -0.014982, 0.232432, 0.03038, -0.214465, 0.619989, 0.29277, 0.314834, 0.086632, 0.161711, -0.034107, -0.151045, 0.020425, 0.218485, 0.3363, -0.034618, 0.152649, 0.016568, 0.086714, -0.018658, 0.070147, 0.213466, 0, 0, 0, 0, 0, 0, 0, 0, -0.932848, -1.003165, -0.341332, -0.11204, 1.406334, -0.336355, -0.339087, -0.51356, -0.162039, -0.226304, 0.072946, -0.812662, -1.701086, -0.499706, -0.990943, -0.813634, 0.173046, 0.459343, 0.2275, -0.360836, 0.026943, -0.040887, 0.278048, 0.260894, 0.572971, 0.346218, -0.134839, 0.316115, 0.409622, 0.585538, 0.303234, 0.714652, 0.786184, 0.578677, 0.503127, 0.057549, 0.57817, 0.46244, 0.543384, 0.525598, 0.213541, -0.168437, 0.219022, -0.072952, 0.042802, -0.152116, 0.084846, -0.107039, 0, 0, 0, 0, 0, 0, 0, 0, 0.016404, 0.997331, 0, -0.076596, 0.018473, 0.256727, 1.249764, 0, 0.086148, -0.025167, -0.064075, 0.493953, 0.415236, 0.085607, 0.059368, 0.152953, 0.456452, 0.602597, -0.184422, -0.427883, -0.039192, -0.606153, 0.359438, 0.393526, 0.065199, 0.087284, -0.273318, -0.571888, -0.279073, -0.229468, 0.099515, 0.424934, -0.111985, -0.293889, -0.338771, -0.519033, -0.802248, -0.402129, -0.086213, -0.265251, -0.095881, -0.013141, -0.060605, -0.248586, -0.186889, -0.638007, -0.488382, 0.139474, 0.223135, 0.119939, 0.1456, -0.079978, -0.148228, 0.420408, 0.253332, -0.016093, 0.060696, 0.119001, -0.070902, 0.062986, -0.050862, 0.152024, 0, -0.170461, -0.286688, -0.561138, 0.683068, -0.082501, 0.034546, 1.100267, -0.019292, 0.064415, -0.276275, -0.481163, -0.189212, 0.56897, 0.247911, -0.337371, -0.040283, -0.098869, 0.406738, -0.468218, -0.123311, -0.305366, 0.321166, -0.290255, -0.277697, 0.182553, 0.047512, 0.10309, 9044e-6, -0.674111, -0.363421, -0.082887, 0.23944, 0.082955, 0.213583, 0.318406, -0.279017, -0.335701, -0.261454, -0.11048, 0.535177, -0.0986, 0.205105, -0.170663, -0.328026, 0.090705, -0.899806, -0.307637, 0.187055, 0.750647, -0.084968, 0.290149, 0.37106, -0.105364, 0.225249, 0.223297, 0.017305, 0.309412, -0.106226, -0.080595, 0.143171, 0.079071, -0.146145, 0.020088, -0.149301, -0.098385, 0.106028, -0.517445, -0.312937, -0.640364, -0.877295, -0.073134, -0.439757, -0.515993, -0.251006, 0.203072, -0.067758, -8098e-6, 0.173627, 0.639688, -0.362933, 0.279757, 0.205514, 0.13706, 0.141828, 0.602961, 0.965688, 0.84515, 0.348515, 0.3326, 0.286962, -0.015751, 0.231855, 0.258724, 0.40637, 0.305512, 0.301613, 0.371449, 0.276078, 0.587148, -0.178944, 0.306949, -0.401699, 0.09096, -0.22661, 0.021549, -0.413624, -0.201687, -0.084201, 0.152123, -0.013036, -0.093466, 0.018512, 0.366355, -0.444549, -0.491823, -0.661309, -0.153672, -0.315484, -0.041765, 0.061645, -0.288833, -0.787222, -0.342308, 0.070218, 0.043248, -0.269705, 0.316763, 0.223498, -0.206234, 0.105871, 0.131789, 0.209583, -0.189817, 0.134778, -0.030606, -0.211052, -0.015656, 0.242842, -0.111455, -0.09217, 0.184252, 0.084914, 0.319446, 0.119898, -0.276555, -0.427884, 0.13321, 0.220705, 0.228857, 9072e-6, -0.460201, -0.016445, 0.029833, -0.027238, -0.303666, -0.014196, 0.52749, 0.136027, -0.485116, -0.32925, -0.646318, 0.360045, -0.030346, 0.306145, 0.207287, 0.347186, 0.147391, -0.301798, -0.162854, -1852e-6, -0.186145, -0.238672, 0.151418, -0.165243, -0.607537, -0.26983, -0.179823, 0.102497, 0.333035, -0.265184, -0.146893, 0.141899, 0.042247, -0.334401, -0.078645, 0.158798, 0.121247, 0.050473, 0.141854, 0.121909, 0.163706, 0.363064, 0.095386, -0.366858, -0.073045, 0.468497, 0.515219, -0.313129, 0.344969, -0.483869, -0.053312, -0.316548, 0.126434, 0.504554, 0.591277, 0.800165, -0.446718, -0.57903, -0.393449, -0.011703, 0.158082, 0.076668, 0.175878, 0.251924, 0.670966, 0.199916, 0.141372, 0.079644, -0.055347, -0.180072, -0.041644, -0.058847, -0.088363, -0.105886, -0.207878, -0.25467, -0.206962, 0.043397, -0.05853, 0.080015, -0.780498, -0.157024, -0.314302, 0.092865, -0.197698, 0.045927, 0.158859, -0.096613, -0.19211, 0.170565, -0.183876, 0.368766, 0.098156, -0.187734, 0.141473, -0.265296, 0.166125, -0.139157, -0.073868, 0, 0.078424, -0.092974, -0.029067, -0.061701, 0, 0.136401, 0.198705, -1.078221, -1.243498, 0.387456, 0.771226, 0.482704, 1.325415, 0, 1.569673, 1.490393, 4.641987, 3.918179, 0.059459, 0.196966, 1.834579, -0.655774, -0.856676, -0.263823, 0, 0.209522, -0.031677, -0.035976, -0.014865, 0.125964, 0.067942, 0.195512, -0.13055, 0, -0.505632, 0, 0.068124, 0, -6001e-6, 0, -0.168293, 0.477676, 0.731389, 0.439841, 0.319029, 0.279835, -0.071747, -0.025259, -0.100505, -0.282656, -0.117859, -0.445104, -0.658698, -0.518833, -553e-6, -493e-6, -185e-6, 0.622944, 0.050047, 0.152839, -0.058867, 0.226208, -7115e-6, 0.01979, -0.089872, -0.353097, -0.224025, 0.054974, 0.132258, -0.291369, -0.117781, -9743e-6, -0.144807, -0.121086, 0.08319, -1.058997, 0, -4e-6, -1e-5, -15e-6, -24e-6, -47e-6, -89e-6, -207e-6, -773e-6, -837e-6, -134e-6, -69e-6, -36e-6, -21e-6, -16e-6, -9e-6, -3e-6, -26e-6, -66e-6, -108e-6, -7e-5, -418e-6, -12e-5, -387e-6, -112e-6, -2e-5, -79e-6, -141e-6, -42e-6, -419e-6, -77e-6, -413e-6, -109e-6, 0.499159, 0.311188, -234e-6] };

  // src/style-features.js
  var pieces = "pnbrqk";
  var file2 = (s) => s.charCodeAt(0) - 97;
  var rank2 = (s, side) => side === "w" ? Number(s[1]) - 1 : 8 - Number(s[1]);
  function styleContext(chess) {
    const side = chess.turn(), board2 = chess.board().flat().filter(Boolean), phase = board2.length > 24 ? 0 : board2.length > 12 ? 1 : 2;
    return { side, phase, own: board2.find((p) => p.type === "k" && p.color === side)?.square ?? "e1", enemy: board2.find((p) => p.type === "k" && p.color !== side)?.square ?? "e8", early: Number(chess.fen().split(" ")[5]) < 10 };
  }
  function moveFeatures(chess, move, context = styleContext(chess)) {
    const p = pieces.indexOf(move.piece), ff = file2(move.from), fr = rank2(move.from, context.side), tf = file2(move.to), tr = rank2(move.to, context.side);
    const ef = file2(context.enemy), er = rank2(context.enemy, context.side), of = file2(context.own), or = rank2(context.own, context.side);
    const features = [0, 1 + p, 7 + ff, 15 + fr, 23 + tf, 31 + tr, 39 + p * 64 + tr * 8 + tf, 423 + p * 64 + fr * 8 + ff, 807 + (move.captured ? pieces.indexOf(move.captured) + 1 : 0), 824 + Math.abs(tf - ff) + Math.abs(tr - fr), 839 + Math.abs(tf - ef) + Math.abs(tr - er), 854 + context.phase, 857 + p * 3 + context.phase, 877 + er, 885 + or, 893 + ef, 901 + of];
    if (move.captured) features.push(814);
    if (move.san.includes("+")) features.push(815);
    if (move.san.includes("#")) features.push(816);
    if (move.flags.includes("k") || move.flags.includes("q")) features.push(817);
    if (move.promotion) features.push(818, 820 + "qrbn".indexOf(move.promotion));
    if (move.flags.includes("e")) features.push(819);
    if (chess.isAttacked(move.to, context.side === "w" ? "b" : "w")) features.push(875);
    if (move.captured && "prq".includes(move.captured)) features.push(909);
    if (Math.abs(tf - ef) + Math.abs(tr - er) <= 2) features.push(910);
    if (context.early) features.push(911);
    return features;
  }
  function sparseScore(weights, features) {
    let score = 0;
    for (const index of features) score += weights[index] ?? 0;
    return score;
  }

  // src/learned-style.ts
  function learnedChoice(fen, lines2) {
    const ranked = [...lines2].sort((a, b) => a.rank - b.rank), best = ranked[0];
    if (!best) return null;
    const c = new Chess(fen), context = styleContext(c), legal = new Map(c.moves({ verbose: true }).map((m) => [m.from + m.to + (m.promotion ?? ""), m]));
    let selected = null;
    for (const line of ranked) {
      if (line.bound) continue;
      if (best.mate !== void 0) {
        if (best.mate <= 0 || line.mate === void 0 || line.mate <= 0 || line.mate > best.mate) continue;
      } else if (line.mate !== void 0) {
        if (line.mate <= 0) continue;
      } else if (best.cp === void 0 || line.cp === void 0 || best.cp - line.cp > 80) continue;
      const move = legal.get(line.pv[0]);
      if (!move) continue;
      const score = sparseScore(witty_model_default.weights, moveFeatures(c, move, context));
      if (!selected || score > selected.score) selected = { move: line.pv[0], line, score };
    }
    return selected;
  }

  // src/tactics.ts
  var value = { p: 1, n: 3, b: 3.25, r: 5, q: 9, k: 0 };
  function material(c, side) {
    let total = 0;
    for (const p of c.board().flat()) if (p) total += (p.color === side ? 1 : -1) * value[p.type];
    return total;
  }
  function humanizeChoice(lines2, humanity) {
    if (lines2.length < 2) return lines2[0] ?? null;
    const best = lines2[0];
    const roll = Math.random() * 100;
    if (roll > humanity) return best;
    const candidates = lines2.slice(0, Math.min(3, lines2.length));
    const weights = candidates.map((_, i) => Math.max(1, 10 - i * 3 - humanity / 20));
    const total = weights.reduce((a, b) => a + b, 0);
    let r = Math.random() * total;
    for (let i = 0; i < candidates.length; i++) {
      r -= weights[i];
      if (r <= 0) return candidates[i];
    }
    return best;
  }
  function trapCandidate(fen, line, best) {
    if (line.bound || best.bound || line.depth < 10 || line.pv.length < 4) return null;
    if (best.cp !== void 0 && line.cp !== void 0) {
      if (best.cp - line.cp > 50 || best.cp - line.cp < 5) return null;
    }
    const c = new Chess(fen);
    try {
      const moves = legalPV(fen, line.pv);
      if (moves.length < 3) return null;
      const first = c.move(moves[0].uci);
      const after = new Chess(c.fen());
      const oppMoves = after.moves().length;
      if (oppMoves > 8) return null;
      const isCheck = first.san.includes("+") || first.san.includes("#");
      const isCapture = !!first.captured;
      if (!isCheck && !isCapture) return null;
      return { move: moves[0].uci, san: first.san, trap: isCheck ? "Forcing check creating trap potential" : isCapture ? "Tactical capture with hidden follow-up" : "Trappy move" };
    } catch {
      return null;
    }
  }
  function practicalChoice(fen, lines2) {
    if (!lines2.length) return null;
    const c = new Chess(fen);
    const turn = c.turn();
    let best = null;
    let bestScore = -Infinity;
    for (const line of lines2) {
      if (line.bound) continue;
      let score = 0;
      if (line.mate !== void 0) {
        score = line.mate > 0 ? 1e4 - line.mate : line.mate > 0 ? 0 : -1e4;
      } else score = line.cp ?? 0;
      if (line.pv.length <= 4) score += 15;
      try {
        const m = c.move({ from: line.pv[0].slice(0, 2), to: line.pv[0].slice(2, 4), promotion: line.pv[0][4] });
        if (m.san.includes("+")) score += 20;
        if (m.captured) score += 10;
        c.undo();
      } catch {
      }
      if (score > bestScore) {
        bestScore = score;
        best = line;
      }
    }
    return best;
  }
  function sacrificeCandidate(fen, line, best) {
    if (line.bound || best.bound || line.depth < 12 || line.pv.length < 3) return null;
    if (best.mate !== void 0) {
      if (best.mate <= 0 || line.mate === void 0 || line.mate <= 0 || line.mate > best.mate + 1) return null;
    } else if (line.mate !== void 0) {
      if (line.mate <= 0) return null;
    } else if (line.cp === void 0 || best.cp === void 0 || line.cp < -30 || best.cp - line.cp > 30) return null;
    const c = new Chess(fen), side = c.turn(), baseline = material(c, side);
    try {
      const moves = legalPV(fen, line.pv);
      if (moves.length < 3) return null;
      const first = c.move(moves[0].uci), piece = first.piece;
      if (value[piece] < 3 || first.isPromotion()) return null;
      const reply = c.move(moves[1].uci);
      if (reply.to !== first.to || reply.captured !== piece || baseline - material(c, side) < 1.5) return null;
      c.move(moves[2].uci);
      if (baseline - material(c, side) < 1.5) return null;
      return { move: moves[0].uci, san: first.san, piece: { n: "knight", b: "bishop", r: "rook", q: "queen", p: "pawn", k: "king" }[piece], depth: line.depth };
    } catch {
      return null;
    }
  }
  function chooseRecommendation(fen, mode2, hunt2, bestmove, lines2, humanity = 0) {
    if (mode2 === "alien") {
      // Always try alien gambit book first (covers 1.e4, Nxe4, Ng5, Nxf7 line)
      const book2 = alienBookMove(fen);
      if (book2) return { move: book2.move, note: "\uD83D\uDC7D Alien Gambit \xB7 " + book2.note, source: "book" };
      // If we're at starting position as White, force e4 to steer toward Caro-Kann
      try {
        var Chess2 = (typeof Chess !== "undefined") ? Chess : null;
        if (Chess2 && fen === "rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1") {
          return { move: "e2e4", note: "\uD83D\uDC7D Alien Gambit \xB7 1.e4 — steering toward Caro-Kann", source: "book" };
        }
      } catch(e) {}
      // Out of book — engine takes over but keep the gambit spirit with hacker strength
    }
    if (mode2 === "witty") {
      const book2 = alienBookMove(fen);
      if (book2) return { move: book2.move, note: book2.note, source: "book" };
    }
    const legal = legalPV(fen, [bestmove]);
    if (!legal.length) return null;
    const ranked = [...lines2].sort((a, b) => a.rank - b.rank), best = ranked[0];
    if (mode2 === "stealth" || humanity > 0) {
      const humanLine = humanizeChoice(ranked, humanity || 50);
      if (humanLine && humanLine.pv[0] !== bestmove) {
        return { move: humanLine.pv[0], line: humanLine, source: "human", note: `Human-like choice \xB7 depth ${humanLine.depth}` };
      }
    }
    if (mode2 === "trap" || hunt2) {
      for (const line of ranked) {
        const trap = trapCandidate(fen, line, best);
        if (trap) return { move: trap.move, line, source: "trap", note: `${trap.trap}: ${trap.san}` };
      }
    }
    if (mode2 === "practical") {
      const prac = practicalChoice(fen, ranked);
      if (prac) return { move: prac.pv[0], line: prac, source: "practical", note: `Practical play \xB7 maximizing winning chances` };
    }
    if (mode2 === "pro" && hunt2 && best) {
      for (const line of ranked) {
        const sacrifice2 = sacrificeCandidate(fen, line, best);
        if (sacrifice2) return { move: sacrifice2.move, line, sacrifice: sacrifice2 };
      }
    }
    if (mode2 === "witty" && best) {
      const learned = learnedChoice(fen, ranked);
      if (learned) return { move: learned.move, line: learned.line, source: "learned", note: "Learned Witty Alien preferences \xB7 position not in the recorded repertoire" };
    }
    return { move: bestmove, line: ranked.find((line) => line.pv[0] === bestmove), source: "engine", note: mode2 === "witty" ? "Learned Witty Alien fallback \xB7 best engine continuation" : void 0 };
  }

  // src/coach.ts
  var STUDY_FOCI = { balanced: { label: "Balanced", note: "Develop pieces, secure your king, and calculate forcing replies." }, witty: { label: "Witty Alien \xB7 gambits", note: "Develop rapidly behind a gambit and coordinate pieces against the king." }, magnus: { label: "Magnus \xB7 conversion", note: "Study conversion: improve pieces, simplify favorable positions, and activate the endgame king." }, hikaru: { label: "Hikaru \xB7 tactics", note: "Study tactics: compare checks, captures, and threats before quiet moves." }, fabiano: { label: "Fabiano \xB7 calculation", note: "Study calculation: examine the opponent\u2019s forcing replies before committing." }, wesley: { label: "Wesley \xB7 king safety", note: "Study safety: check king exposure and loose pieces before opening the position." }, alireza: { label: "Alireza \xB7 initiative", note: "Study initiative: develop with tempo and coordinate active pieces." } };
  function focusId(value2) {
    return typeof value2 === "string" && Object.hasOwn(STUDY_FOCI, value2) ? value2 : "balanced";
  }
  var names = { p: "pawn", n: "knight", b: "bishop", r: "rook", q: "queen", k: "king" };
  var values = { p: 1, n: 3, b: 3.25, r: 5, q: 9, k: 0 };
  function coaching(fen, uci, pv = [], focus = "balanced") {
    const c = new Chess(fen), side = c.turn(), opponent = side === "w" ? "b" : "w", board2 = c.board().flat().filter((p) => p !== null), moves = c.moves({ verbose: true });
    const selected = moves.find((m) => m.from + m.to + (m.promotion ?? "") === uci), rank3 = side === "w" ? "1" : "8";
    let action = "Choose a legal recommendation to see move instructions.", promotion = "", castling = "";
    if (selected) {
      action = `Move the ${names[selected.piece]} from ${selected.from} to ${selected.to}${selected.captured ? `, capturing the ${names[selected.captured]}` : ""}.`;
      if (selected.flags.includes("q") || selected.flags.includes("k")) {
        const queenside = selected.flags.includes("q");
        castling = `Castle ${queenside ? "queenside" : "kingside"}: king ${selected.from} \u2192 ${selected.to}; rook ${queenside ? "a" : "h"}${rank3} \u2192 ${queenside ? "d" : "f"}${rank3}.`;
        action = castling;
      }
      if (selected.promotion) promotion = `Promote to ${names[selected.promotion]}. After ${selected.from} \u2192 ${selected.to}, choose ${names[selected.promotion]} in the promotion picker.`;
      if (selected.flags.includes("e")) action = `En passant: move the pawn ${selected.from} \u2192 ${selected.to}; the pawn on ${selected.to[0]}${selected.from[1]} is captured.`;
    }
    const material2 = board2.reduce((n, p) => n + (p.color === side ? 1 : -1) * values[p.type], 0), minorHomes = ["b", "g", "c", "f"].map((file3) => file3 + rank3);
    const undeveloped = board2.filter((p) => p.color === side && ["n", "b"].includes(p.type) && minorHomes.includes(p.square) && p.square !== selected?.from);
    const center = ["d4", "e4", "d5", "e5"].filter((s) => c.isAttacked(s, side)).length;
    const loose = board2.filter((p) => p.color === side && !["p", "k"].includes(p.type) && c.isAttacked(p.square, opponent) && !c.isAttacked(p.square, side));
    const plans = [];
    if (c.isCheck()) plans.push("Your king is in check: address the check before pursuing another plan.");
    if (loose.length) plans.push(`Calculate threats to the ${loose.slice(0, 2).map((p) => `${names[p.type]} on ${p.square}`).join(" and ")}; these pieces are attacked and not directly defended.`);
    if (Number(c.fen().split(" ")[5]) <= 15 && undeveloped.length) plans.push(`Develop the remaining home-square pieces: ${undeveloped.map((p) => `${names[p.type]} ${p.square}`).join(", ")}.`);
    if (!castling && moves.some((m) => m.flags.includes("q"))) plans.push("Queenside castling is legal in this position; compare its king safety with the current engine line.");
    else if (!castling && moves.some((m) => m.flags.includes("k"))) plans.push("Kingside castling is legal in this position; consider completing king safety.");
    if (center < 2 && board2.length > 14) plans.push("Increase piece and pawn influence over d4, e4, d5 and e5.");
    if (material2 >= 3 && focus !== "witty") plans.push("You have extra material: look for safe simplifications after checking tactics.");
    if (board2.length <= 10) plans.push("Look for king activity and passed-pawn plans, while respecting checks and pawn promotion races.");
    if (!plans.length) plans.push(focus === "witty" ? "Coordinate another piece with the attack; calculate before offering material." : "Improve your least active piece and check the opponent\u2019s forcing replies.");
    const verified = pv[0] === uci ? legalPV(fen, pv) : [];
    return { action, promotion, castling, plans: plans.slice(0, 3), material: `Material balance for ${side === "w" ? "White" : "Black"}: ${material2 >= 0 ? "+" : ""}${material2.toFixed(1)} pawns`, continuation: verified.length ? verified.slice(0, 7).map((m) => m.san).join(" ") : "No scored engine continuation is attached to this move.", focusNote: STUDY_FOCI[focus].note };
  }

  // src/promotion.ts
  function visiblePiece(placement2, square) {
    if (!placement2) return null;
    const row = placement2.split("/")[8 - Number(square[1])];
    if (!row) return null;
    const target = square.charCodeAt(0) - 97;
    let file3 = 0;
    for (const token of row) {
      if (/[1-8]/.test(token)) {
        file3 += Number(token);
        continue;
      }
      if (file3 === target) return token;
      file3++;
    }
    return null;
  }
  function promotionWaiting(placement2, advice) {
    return !!advice && visiblePiece(placement2, advice.to) === (advice.color === "w" ? "P" : "p") && visiblePiece(placement2, advice.from) === null;
  }

  // src/content.ts
  var nonce = crypto.randomUUID();
  var tracker = new PositionTracker();
  var board = null;
  var current = "";
  var candidate = "";
  var stableSince = 0;
  var bridgeFen = null;
  var boardStatus = "Searching for board";
  var status = "Waiting";
  var auto = true;
  var overlayEnabled = true;
  var depth = 16;
  var revision = 0;
  var lastPath = "";
  var lastRead = 0;
  var dirty = true;
  var flipped = false;
  var lines = /* @__PURE__ */ new Map();
  var manualPending = null;
  var engineFailed = false;
  var delivery = Promise.resolve();
  var collector = new MultiPV(3);
  var mode = "hacker";
  var hunt = true;
  var selectedMove = "";
  var selectedLine;
  var sacrifice;
  var styleNote = "";
  var repertoireAvailable = true;
  var pace = "balanced";
  var studyFocus = "balanced";
  var promotionAdvice = null;
  var promotionInProgress = false;
  var soundEnabled = true;
  var autoMoveEnabled = false;
  var showArrow = true;
  var streamProof = false;
  var lastBestMove = "";
  var selectedAltUCI = "";
  var host = document.createElement("div");
  host.id = "chess-vision-assistant";
  host.style.cssText = "position:fixed;right:14px;top:70px;z-index:2147483646;max-width:calc(100vw - 20px)";
  var shadow = host.attachShadow({ mode: "open" });
  shadow.innerHTML = `<style>
:host{color-scheme:dark;font-family:Inter,system-ui,sans-serif;font-size:13px;color:#fff}
*{box-sizing:border-box;margin:0;padding:0}
@keyframes fadeUp{from{opacity:0;transform:translateY(4px)}to{opacity:1;transform:translateY(0)}}

section{width:290px;max-width:calc(100vw - 20px);background:#000;border:1px solid #222;box-shadow:0 8px 32px rgba(0,0,0,.8);animation:fadeUp .18s ease}

/* HEADER */
header{padding:14px 16px 13px;border-bottom:1px solid #1a1a1a;display:flex;justify-content:space-between;align-items:center}
.hd-left{display:flex;flex-direction:column;gap:2px}
.hd-name{font-size:16px;font-weight:700;letter-spacing:-.4px;color:#fff;line-height:1}
.hd-color{font-size:11px;color:#555;font-weight:400;line-height:1}
.hd-color b{color:#fff;font-weight:600}
#collapse{background:none;border:none;color:#444;font-size:18px;cursor:pointer;padding:2px;line-height:1;transition:color .12s}
#collapse:hover{color:#fff}

/* MAIN */
main{padding:14px 16px;max-height:74vh;overflow-y:auto;overflow-x:hidden;scrollbar-width:thin;scrollbar-color:#222 #000}

/* BEST MOVE — the one loud thing */
.move-block{margin:0 0 14px}
.move-num{font-size:52px;font-weight:800;letter-spacing:-2px;color:#22c55e;line-height:1;min-height:56px}
.move-meta{display:flex;align-items:center;gap:10px;margin-top:5px}
#turn{font-size:11px;color:#555}
#move-score{font-size:11px;color:#555;margin-left:auto}
#status{font-size:11px;color:#555;margin-bottom:12px}

/* EVAL BAR — minimal */
#evalbar{height:3px;background:#1a1a1a;margin-bottom:14px;position:relative}
#evalfill{height:100%;width:50%;background:#22c55e;transition:width .4s ease;position:absolute;right:0}

/* DIVIDER */
.div{height:1px;background:#1a1a1a;margin:12px 0}

/* BUTTONS — 2 col grid, flat, no border radius */
.btn-grid{display:grid;grid-template-columns:1fr 1fr;gap:1px;background:#1a1a1a;margin-bottom:1px}
.btn-grid button,.btn-full{font:600 11px/1 Inter,sans-serif;padding:10px 8px;background:#000;border:none;color:#555;cursor:pointer;transition:color .12s,background .12s;text-align:center;letter-spacing:.2px}
.btn-grid button:hover,.btn-full:hover{background:#0f0f0f;color:#fff}
.btn-grid button.on{color:#22c55e}
.btn-full{display:block;width:100%;background:#000;border:none;border-top:1px solid #1a1a1a;color:#555;cursor:pointer;font:600 11px/1 Inter,sans-serif;padding:10px 16px;text-align:left;transition:color .12s,background .12s;letter-spacing:.2px}
.btn-full:hover{background:#0f0f0f;color:#fff}
.btn-full.on{color:#22c55e}

/* SELECTS */
.row{display:flex;justify-content:space-between;align-items:center;padding:8px 0;border-bottom:1px solid #111;font-size:12px;color:#888;gap:8px}
.row:last-child{border-bottom:none}
select,input[type=number]{font:12px/1 Inter,sans-serif;color:#fff;background:#0d0d0d;border:1px solid #222;padding:5px 7px;cursor:pointer;-webkit-appearance:none;appearance:none;transition:border-color .12s;min-width:0}
select:focus,input[type=number]:focus{border-color:#22c55e;outline:none}
input[type=number]{width:52px;text-align:center}
input[type=checkbox]{accent-color:#22c55e;width:13px;height:13px;cursor:pointer}

/* ALTERNATIVES */
ol{list-style:none;margin:0}
li{display:flex;align-items:baseline;gap:8px;padding:8px 0;border-bottom:1px solid #111;cursor:pointer;font-size:12px;transition:background .1s}
li:last-child{border-bottom:none}
li:hover{background:#0a0a0a}
li.sel .li-san{color:#22c55e}
.li-num{color:#333;font-size:11px;width:14px;flex-shrink:0}
.li-san{font-weight:700;color:#fff}
li span{color:#555;margin-left:auto;font-size:11px}
li small{font-size:10px;color:#333;overflow-wrap:anywhere}

/* TACTIC / PROMO / ACTION */
#tactic{font-size:11px;color:#555;margin:8px 0;line-height:1.5}
#tactic.found{color:#22c55e}
#promotion{color:#22c55e;padding:8px 0;font-weight:700;font-size:13px;animation:fadeUp .2s}
#action{font-size:11px;color:#555;line-height:1.6;padding:6px 0}
#mode-hint{font-size:10px;color:#333;line-height:1.5;padding:6px 0}

/* DETAILS */
details{border-top:1px solid #1a1a1a}
summary{cursor:pointer;user-select:none;padding:10px 0;font-size:12px;font-weight:600;color:#555;list-style:none;display:flex;justify-content:space-between;align-items:center;transition:color .12s}
summary::-webkit-details-marker{display:none}
summary::after{content:'+';font-size:14px;color:#333;line-height:1}
details[open] summary::after{content:'−'}
summary:hover{color:#fff}
.det-body{padding:0 0 10px;font-size:11px;color:#555;line-height:1.6}
.det-body p{margin:4px 0}
.det-body ul{padding-left:12px;margin:4px 0}

/* TEXTAREA */
textarea{width:100%;height:52px;font:11px/1.5 monospace;color:#888;background:#0d0d0d;border:1px solid #222;padding:6px 8px;resize:none;margin:6px 0}
textarea:focus{border-color:#22c55e;outline:none}
#error{color:#ef4444;font-size:11px;margin-top:4px}

/* ANALYZE BTN */
#analyze{width:100%;padding:10px;background:#fff;border:none;color:#000;font:700 12px/1 Inter,sans-serif;cursor:pointer;margin:10px 0 4px;letter-spacing:.3px;transition:background .12s}
#analyze:hover{background:#e5e5e5}

/* LEGEND */
.legend{display:flex;gap:16px;padding:6px 0;font-size:11px;color:#333}
.legend span{display:flex;align-items:center;gap:5px}
.leg-dot{width:7px;height:7px;border-radius:50%;flex-shrink:0}

#board{font-size:11px;color:#333;margin-bottom:4px}
footer{font-size:10px;color:#333;padding-top:10px;border-top:1px solid #111;line-height:1.6}
#arrowCanvas{position:fixed;pointer-events:none;z-index:2147483644}
.qc-priv-input,.qc-priv-select{font:11px/1 Inter,sans-serif;color:#fff;background:#0d0d0d;border:1px solid #222;padding:5px 7px;max-width:120px;cursor:pointer;transition:border-color .12s}
.qc-priv-input{max-width:128px}.qc-priv-input::placeholder{color:#333}
.qc-priv-input:focus,.qc-priv-select:focus{border-color:#22c55e;outline:none}
.qc-title-badge{font-size:10px;font-weight:800;padding:1px 5px;border-radius:2px;margin-right:4px;vertical-align:middle;letter-spacing:.3px;display:inline-block}
</style>
<section>
<header>
  <div class="hd-left">
    <div class="hd-name">QuickChess</div>
    <div class="hd-color" id="color-badge">detecting color…</div>
  </div>
  <button id="collapse" aria-label="Collapse">×</button>
</header>
<main>
  <div id="status">Waiting for game…</div>
  <div class="move-block">
    <div class="move-num" id="best">—</div>
    <div class="move-meta">
      <div id="turn">not your turn</div>
      <div id="move-score"></div>
    </div>
  </div>
  <div id="evalbar"><div id="evalfill"></div></div>
  <div id="board"></div>
  <div class="btn-grid">
    <button id="btn-automove">▶ Auto-Move</button>
    <button id="btn-sound">Sound</button>
    <button id="btn-arrow">Arrow</button>
    <button id="btn-analyze2">Analyze</button>
  </div>
  <button class="btn-full" id="btn-stream">Stream Safe  <span style="color:#333;font-weight:400;float:right">Shift+S</span></button>
  <div class="div"></div>
  <div class="row"><span>Mode</span><select id="mode" aria-label="Playing mode"><option value="noob">Noob</option><option value="intermediate">Intermediate</option><option value="pro">Pro</option><option value="hacker" selected>Hacker</option><option value="magnus">Magnus</option><option value="witty">Witty Alien</option><option value="stealth">Stealth</option><option value="trap">Trap</option><option value="practical">Practical</option><option value="alien">Alien Gambit</option></select></div>
  <div class="row"><span>Pace</span><select id="pace" aria-label="Analysis pace"><option value="instant">Instant</option><option value="quick">Quick</option><option value="balanced" selected>Balanced</option><option value="deep">Deep</option></select></div>
  <input id="hunt" type="checkbox" checked disabled style="display:none">
  <div id="mode-hint"></div>
  <div id="tactic" role="status"></div>
  <div id="action"></div>
  <div id="promotion" hidden role="status"></div>
  <details id="coach-panel">
    <summary>Continuation</summary>
    <div class="det-body">
      <div class="row" style="border:none;padding-top:0"><span>Focus</span><select id="study-focus" aria-label="Study focus">${Object.entries(STUDY_FOCI).map(([id, focus]) => `<option value="${id}">${focus.label}</option>`).join("")}</select></div>
      <p id="study-note"></p>
      <ul id="plans"></ul>
      <p id="material"></p>
      <p id="continuation" style="margin-top:4px"></p>
    </div>
  </details>
  <details>
    <summary id="alternatives">Alternatives</summary>
    <div class="det-body" style="padding-bottom:0">
      <ol id="moves"></ol>
    </div>
  </details>
  <div class="div"></div>
  <div class="row"><span>Depth</span><input id="depth" aria-label="Search depth" type="number" min="1" max="40" value="16"></div>
  <div class="row"><span>Auto-analyze</span><input id="auto" type="checkbox" checked></div>
  <div class="row"><span>Highlights</span><input id="overlay" type="checkbox" checked></div>
  <button id="analyze">Analyze</button>
  <div class="legend">
    <span><div class="leg-dot" style="background:#22c55e"></div>Move</span>
    <span><div class="leg-dot" style="background:#ef4444"></div>Destination</span>
  </div>
  <details>
    <summary>FEN</summary>
    <div class="det-body">
      <textarea id="fen" aria-label="Full FEN" placeholder="Paste FEN here"></textarea>
      <button id="load" style="width:100%;padding:8px;background:#fff;border:none;color:#000;font:700 11px/1 Inter,sans-serif;cursor:pointer">Load</button>
      <div id="error"></div>
    </div>
  </details>
  <div class="div"></div>
  <div class="sec-head">Streamer Privacy</div>

  <div class="row"><span>My Username</span><input type="text" id="qc-my-username" class="qc-priv-input" placeholder="your chess.com name" /></div>
  <div class="row" style="margin-top:4px">
    <span>Hide My Name</span>
    <select id="qc-select-mine" class="qc-priv-select">
      <option value="off">Show real</option>
      <option value="replace">Custom name</option>
      <option value="random">Random name</option>
    </select>
  </div>
  <div class="row" id="qc-custom-mine-wrap" style="display:none">
    <span style="color:var(--g5);font-size:11px">Display as</span>
    <input type="text" id="qc-custom-mine" class="qc-priv-input" placeholder="Streamer" />
  </div>
  <div class="row" style="margin-top:4px">
    <span>Spoof as Player</span>
    <input type="text" id="qc-spoof-name" class="qc-priv-input" placeholder="e.g. Hikaru" />
  </div>
  <div class="row">
    <span>Title Badge</span>
    <select id="qc-title-select" class="qc-priv-select">
      <option value="none">None</option>
      <option value="GM">GM</option>
      <option value="IM">IM</option>
      <option value="FM">FM</option>
      <option value="CM">CM</option>
      <option value="NM">NM</option>
    </select>
  </div>
  <div class="row">
    <span>Spoof ELO</span>
    <input type="text" id="qc-spoof-elo" class="qc-priv-input" placeholder="e.g. 3200" style="width:80px" />
  </div>
  <div class="row">
    <span>Hide Opponent</span>
    <select id="qc-select-opp" class="qc-priv-select">
      <option value="off">Show real</option>
      <option value="replace">Opponent</option>
      <option value="random">Random name</option>
    </select>
  </div>

  <footer>v${chrome.runtime.getManifest().version} · Names by vDoomedSheep · Built by Gavin &amp; Static</footer>
</main>
</section>`;
  var el = (id) => shadow.getElementById(id);

  // ── QUICKCHESS PRIVACY (BadChess merged) ──
  var QC_FAKE_NAMES = [
    "CastleMaster","KnightRider","PawnStar","CheckMate99","RookieError",
    "BlunderBoss","ForkYou","SkeweredKing","EnPassantBro","ZugzwangKid",
    "PinAndWin","SkewerSlayer","DiscoveredAce","DoubleCheckDave","MateInThree",
    "EternalChecker","TheGambiter","SicilianDragon","CaroKannKing","FrenchDefense",
    "LondonSystem","QueenGambit","KingsIndian","NimzoNinja","GruenfelGuru",
    "BenkoBreaker","DutchAttack","PirateGambit","ElephantTrap","HorseyMaster",
    "TowerClimber","DiagonalKing","OpenFileOtto","ClosedGameClay","TempoTaker",
    "MaterialManiac","PositionalPete","TacticalTerry","EndgameEmma","OpponentSlayer"
  ];
  var QC_TITLE_STYLES = {
    GM:'background:#9b2226;color:#fff',
    IM:'background:#b5451b;color:#fff',
    FM:'background:#7b6b00;color:#fff',
    CM:'background:#1e6b3a;color:#fff',
    NM:'background:#2a4a7a;color:#fff',
  };
  function qcFakeName(seed) {
    return QC_FAKE_NAMES[Math.abs(seed) % QC_FAKE_NAMES.length];
  }
  function qcInjectBadge(el2, title) {
    var old2 = el2.parentElement && el2.parentElement.querySelector('.qc-title-badge');
    if (old2) old2.remove();
    if (!title || title === 'none') return;
    var b = document.createElement('span');
    b.className = 'qc-title-badge';
    b.textContent = title;
    b.style.cssText = (QC_TITLE_STYLES[title] || 'background:#555;color:#fff') + ';font-size:10px;font-weight:800;padding:1px 5px;border-radius:2px;margin-right:4px;vertical-align:middle;';
    el2.parentElement && el2.parentElement.insertBefore(b, el2);
  }
  function qcApplyPrivacy() {
    try {
      if (!chrome.runtime?.id) return;
      chrome.storage.local.get([
        'qc-my-username','qc-select-mine','qc-custom-mine',
        'qc-spoof-name','qc-title-select','qc-select-opp','qc-spoof-elo','qc-spoof-elo'
      ], function(d) {
        if (!d) return;
        var myUser   = (d['qc-my-username'] || '').toLowerCase().trim();
        var mineMode = d['qc-select-mine']  || 'off';
        var custom   = (d['qc-custom-mine'] || 'Streamer').trim() || 'Streamer';
        var spoof    = (d['qc-spoof-name']  || '').trim();
        var title    = d['qc-title-select'] || 'none';
        var oppMode  = d['qc-select-opp']   || 'off';
        var spoofElo = (d['qc-spoof-elo'] || '').trim();
        var els = document.querySelectorAll(
          '.user-tagline-name,.user-username,.username,[data-user-link],' +
          '.board-player-username,.user-row-name,.cc-user-username,' +
          '.game-row-player,.archive-games-user,[class*="username"]'
        );
        els.forEach(function(e) {
          if (e.closest('#chess-vision-assistant')) return;
          if (e.closest('th') || e.tagName === 'TH') return;
          var txt = (e.innerText || e.textContent || '').trim();
          if (!txt || txt.length < 2 || txt.length > 40) return;
          var known = ['Streamer','Opponent','GM','IM','FM','CM','NM'].concat(QC_FAKE_NAMES);
          if (!e.dataset.qcOrig && known.indexOf(txt) === -1) e.dataset.qcOrig = txt;
          var orig = e.dataset.qcOrig || txt;
          var lower = orig.toLowerCase();
          var isMe = myUser ? (lower === myUser || lower.includes(myUser)) : false;
          function withRating(n) {
            return orig.includes('(') ? n + ' ' + orig.substring(orig.indexOf('(')) : n;
          }
          if (isMe) {
            var display = orig;
            if (spoof) display = withRating(spoof);
            else if (mineMode === 'replace') display = withRating(custom);
            else if (mineMode === 'random') {
              var s = 0; for (var i = 0; i < orig.length; i++) s += orig.charCodeAt(i);
              display = withRating(qcFakeName(s));
            }
            if (e.innerText !== display) e.innerText = display;
            qcInjectBadge(e, title);
          // ELO spoof: replace rating elements near this name element
          if (spoofElo) {
            var parent = e.parentElement || e;
            var ratingEl = parent.querySelector('[class*="rating"], .user-tagline-rating, .board-player-rating');
            if (!ratingEl) {
              // try siblings
              var sib = e.nextElementSibling;
              while (sib) {
                var sibClass = sib.className || '';
                if (sibClass.includes('rating') || sibClass.includes('elo')) { ratingEl = sib; break; }
                sib = sib.nextElementSibling;
              }
            }
            if (ratingEl) {
              if (!ratingEl.dataset.qcOrigElo) ratingEl.dataset.qcOrigElo = ratingEl.innerText;
              ratingEl.innerText = spoofElo;
            }
            // also fix inline rating in name like "Username (1234)" — replace the number
            if (e.innerText && e.innerText.includes('(')) {
              var newDisplay = e.innerText.replace(/\((\d+)\)/, '(' + spoofElo + ')');
              if (e.innerText !== newDisplay) e.innerText = newDisplay;
            }
          }
          } else {
            var skip = e.closest('.your-games-component,.recommend-match-component');
            var skipW = ['min','nov','dec','jan','badchess','streamer','opponent'];
            if (!skip && !skipW.some(function(w){return lower.includes(w);}) && orig.length > 2) {
              var od = orig;
              if (oppMode === 'replace') od = withRating('Opponent');
              else if (oppMode === 'random') {
                var s2 = 0; for (var j = 0; j < orig.length; j++) s2 += orig.charCodeAt(j);
                od = withRating(qcFakeName(s2 + 999));
              }
              if (e.innerText !== od) e.innerText = od;
            }
          }
        });
      });
    } catch(e2) {}
  }
  function qcSavePrivacy() {
    try {
      if (!chrome.runtime?.id) return;
      var wrap = shadow.getElementById('qc-custom-mine-wrap');
      var mineSelect = shadow.getElementById('qc-select-mine');
      if (wrap) wrap.style.display = (mineSelect && mineSelect.value === 'replace') ? 'flex' : 'none';
      chrome.storage.local.set({
        'qc-my-username': (shadow.getElementById('qc-my-username')||{}).value || '',
        'qc-select-mine': (shadow.getElementById('qc-select-mine')||{}).value || 'off',
        'qc-custom-mine': (shadow.getElementById('qc-custom-mine')||{}).value || '',
        'qc-spoof-name':  (shadow.getElementById('qc-spoof-name') ||{}).value || '',
        'qc-title-select':(shadow.getElementById('qc-title-select')||{}).value || 'none',
        'qc-select-opp':  (shadow.getElementById('qc-select-opp') ||{}).value || 'off',
        'qc-spoof-elo':   (shadow.getElementById('qc-spoof-elo')  ||{}).value || '',
      }, qcApplyPrivacy);
    } catch(e2) {}
  }

  var overlay = document.createElement("div");
  overlay.id = "chess-vision-overlay";
  overlay.style.cssText = "position:fixed;pointer-events:none;z-index:2147483645;contain:strict;display:none";
  var source = document.createElement("div");
  var dest = document.createElement("div");
  for (const [node2, color] of [[source, "#35e884"], [dest, "#ff4657"]]) {
    node2.style.cssText = `position:absolute;width:12.5%;height:12.5%;box-sizing:border-box;background:${color}55;border:3px solid ${color};border-radius:12%;transition:all .18s;pointer-events:none;box-shadow:0 0 12px ${color}88`;
    overlay.append(node2);
  }
  document.documentElement.append(host, overlay);
  var arrowCanvas = document.createElement("canvas");
  arrowCanvas.id = "cv-arrow";
  arrowCanvas.style.cssText = "position:fixed;left:0;top:0;pointer-events:none;z-index:2147483644;display:none";
  document.documentElement.append(arrowCanvas);
  function command(data) {
    const requestRevision = revision;
    delivery = delivery.catch(() => {
    }).then(async () => {
      try {
        const result = await chrome.runtime.sendMessage({ target: "background", type: "CV_REQUEST", nonce, data });
        if (result?.error) throw Error(result.error);
      } catch (error) {
        if (!data.stop && revision === requestRevision) {
          engineFailed = true;
          status = String(error);
          lines.clear();
          source.dataset.square = "";
          dest.dataset.square = "";
          draw();
          render();
        }
      }
    });
  }
  function cancel() {
    revision++;
    command({ stop: true });
    lines.clear();
    collector = new MultiPV(3);
    selectedMove = "";
    selectedLine = void 0;
    sacrifice = void 0;
    styleNote = "";
    host.dataset.moveSource = "";
    host.dataset.recordedGame = "";
    host.dataset.engineMove = "";
    source.dataset.square = "";
    dest.dataset.square = "";
    selectedAltUCI = "";
    draw();
    drawArrow();
  }
  function isPlayersTurn() {
    if (!current) return false;
    var fenTurn = current.split(" ")[1]; // 'w' or 'b'
    var playerIsWhite = !flipped;
    return (fenTurn === "w" && playerIsWhite) || (fenTurn === "b" && !playerIsWhite);
  }
  function draw() {
    if (!board || !overlayEnabled || !source.dataset.square || !allowedPage(location.pathname)) {
      overlay.style.display = "none";
      return;
    }
    // COLOR LOCK: only show overlay on player's own turn
    if (!isPlayersTurn()) {
      overlay.style.display = "none";
      return;
    }
    const r = board.getBoundingClientRect();
    overlay.style.display = "block";
    Object.assign(overlay.style, { left: `${r.left}px`, top: `${r.top}px`, width: `${r.width}px`, height: `${r.height}px` });
    for (const node2 of [source, dest]) {
      const p = squareBox(node2.dataset.square, flipped);
      node2.style.left = `${p.x}%`;
      node2.style.top = `${p.y}%`;
    }
  }
  function playSound(kind = "move") {
    if (!soundEnabled) return;
    try {
      const ctx = new (window.AudioContext || window.webkitAudioContext)();
      const o = ctx.createOscillator(), g = ctx.createGain();
      o.connect(g);
      g.connect(ctx.destination);
      const freq = kind === "best" ? 880 : kind === "error" ? 220 : 440;
      o.frequency.value = freq;
      o.type = kind === "best" ? "triangle" : "sine";
      g.gain.setValueAtTime(0.08, ctx.currentTime);
      g.gain.exponentialRampToValueAtTime(1e-3, ctx.currentTime + 0.15);
      o.start();
      o.stop(ctx.currentTime + 0.15);
    } catch {
    }
  }
  function drawArrow() {
    if (!showArrow || !board || !selectedMove || selectedMove.length < 4) {
      arrowCanvas.style.display = "none";
      return;
    }
    const r = board.getBoundingClientRect();
    arrowCanvas.width = window.innerWidth;
    arrowCanvas.height = window.innerHeight;
    arrowCanvas.style.display = "block";
    const ctx = arrowCanvas.getContext("2d");
    if (!ctx) return;
    ctx.clearRect(0, 0, arrowCanvas.width, arrowCanvas.height);
    const from = squareBox(selectedMove.slice(0, 2), flipped), to = squareBox(selectedMove.slice(2, 4), flipped);
    const x1 = r.left + from.x / 100 * r.width + r.width / 16, y1 = r.top + from.y / 100 * r.height + r.height / 16;
    const x2 = r.left + to.x / 100 * r.width + r.width / 16, y2 = r.top + to.y / 100 * r.height + r.height / 16;
    ctx.strokeStyle = "#35e884cc";
    ctx.lineWidth = 6;
    ctx.lineCap = "round";
    ctx.beginPath();
    ctx.moveTo(x1, y1);
    ctx.lineTo(x2, y2);
    ctx.stroke();
    const ang = Math.atan2(y2 - y1, x2 - x1), len = 14;
    ctx.fillStyle = "#35e884cc";
    ctx.beginPath();
    ctx.moveTo(x2, y2);
    ctx.lineTo(x2 - len * Math.cos(ang - 0.4), y2 - len * Math.sin(ang - 0.4));
    ctx.lineTo(x2 - len * Math.cos(ang + 0.4), y2 - len * Math.sin(ang + 0.4));
    ctx.closePath();
    ctx.fill();
  }
  // Human-like jitter: offset clicks ±jitter pixels so every move looks slightly different
  function humanJitter(px) {
    // ±4px random offset — no two clicks land on the exact same pixel
    return px + (Math.random() - 0.5) * 8;
  }
  function wait(ms) {
    return new Promise(function(resolve) { setTimeout(resolve, ms); });
  }
  // Fire pointer+mouse events on the actual element at (x,y) using elementFromPoint.
  // chess.com's wc-chess-board React listeners are attached to the board element itself
  // and to whatever element is under the pointer — not to document.
  function fireAt(x, y, ptype, mtype, buttons) {
    var pointerOpts = {
      bubbles: true, cancelable: true, composed: true,
      clientX: x, clientY: y, screenX: x + window.scrollX, screenY: y + window.scrollY,
      pointerId: 1, pointerType: "mouse", isPrimary: true,
      buttons: buttons, button: buttons > 0 ? 0 : 0,
      pressure: buttons > 0 ? 0.5 : 0,
      movementX: 0, movementY: 0, width: 1, height: 1
    };
    var mouseOpts = {
      bubbles: true, cancelable: true, composed: true,
      clientX: x, clientY: y, button: 0, buttons: buttons
    };
    // hit the specific element under cursor (piece div or square div)
    var target = document.elementFromPoint(x, y) || board;
    target.dispatchEvent(new PointerEvent(ptype, pointerOpts));
    target.dispatchEvent(new MouseEvent(mtype, mouseOpts));
    // also bubble up to the board element in case React captured it there
    if (target !== board && board) {
      board.dispatchEvent(new PointerEvent(ptype, pointerOpts));
      board.dispatchEvent(new MouseEvent(mtype, mouseOpts));
    }
  }
  async function autoMovePiece() {
    if (!autoMoveEnabled || !board || !selectedMove || selectedMove.length < 4) return;
    // COLOR LOCK: never auto-move on opponent's turn
    if (!isPlayersTurn()) return;
    try {
      var r = board.getBoundingClientRect();
      // squareBox returns {x,y} as percentages (0-87.5), center of square = x% + half a square (12.5%/2 = 6.25%)
      var sq = function(s) {
        var p = squareBox(s, flipped);
        return {
          x: humanJitter(r.left + (p.x + 6.25) / 100 * r.width),
          y: humanJitter(r.top  + (p.y + 6.25) / 100 * r.height)
        };
      };
      var from = sq(selectedMove.slice(0, 2));
      var to   = sq(selectedMove.slice(2, 4));

      // 1. pointerdown on source piece
      fireAt(from.x, from.y, "pointerdown", "mousedown", 1);
      await wait(50 + Math.random() * 60);

      // 2. small drag motion (looks human, also triggers chess.com drag mode)
      var mid = {
        x: from.x + (to.x - from.x) * (0.3 + Math.random() * 0.2),
        y: from.y + (to.y - from.y) * (0.3 + Math.random() * 0.2)
      };
      fireAt(mid.x, mid.y, "pointermove", "mousemove", 1);
      await wait(30 + Math.random() * 50);

      // 3. arrive at destination
      fireAt(to.x, to.y, "pointermove", "mousemove", 1);
      await wait(20 + Math.random() * 30);

      // 4. release on destination
      fireAt(to.x, to.y, "pointerup", "mouseup", 0);
      await wait(10);

      // 5. click — chess.com uses click-to-move as well as drag-to-move
      //    fire click on the destination square for the click-select style
      var clickTarget = document.elementFromPoint(to.x, to.y) || board;
      clickTarget.dispatchEvent(new MouseEvent("click", { bubbles: true, cancelable: true, composed: true, clientX: to.x, clientY: to.y, button: 0, buttons: 0 }));
      if (clickTarget !== board && board) {
        board.dispatchEvent(new MouseEvent("click", { bubbles: true, cancelable: true, composed: true, clientX: to.x, clientY: to.y, button: 0, buttons: 0 }));
      }
    } catch(e) {
      // silent
    }
  }
  function render() {
    host.dataset.fen = current;
    host.dataset.mode = mode;
    const settings = searchSettings(mode, depth, pace);
    el("mode-hint").textContent = `${settings.description}. Skill ${settings.skill}/20 \xB7 depth \u2264 ${settings.depth} \xB7 ${settings.time / 1e3}s \xB7 ${settings.hash}MB hash.${mode === "witty" && !repertoireAvailable ? " Recorded-move lookup unavailable; using fallback." : ""}`;
    el("hunt").disabled = mode !== "pro";
    el("status").textContent = status;
    el("board").textContent = boardStatus;
    const pv = selectedMove && current ? legalPV(current, [selectedMove]) : [];
    const bestText = pv[0]?.san ?? "\u2014";
    el("best").textContent = bestText;
    if (bestText !== "\u2014" && bestText !== lastBestMove) {
      lastBestMove = bestText;
      playSound("best");
    }
    el("turn").textContent = current ? `${current.split(" ")[1] === "w" ? "White" : "Black"} to move${selectedLine ? ` \xB7 ${scoreLabel(selectedLine, current.split(" ")[1])} \xB7 depth ${selectedLine.depth}` : ""}` : "Waiting for verified position";
    let evalPct = 50;
    if (selectedLine) {
      if (selectedLine.mate !== void 0) {
        evalPct = selectedLine.mate > 0 ? 95 : 5;
      } else if (selectedLine.cp !== void 0) {
        const v = Math.max(-8, Math.min(8, selectedLine.cp / 100));
        evalPct = 50 + v * 5;
      }
    }
    el("evalfill").style.width = `${evalPct}%`;
    el("tactic").classList.toggle("found", !!sacrifice || mode === "witty" && !!styleNote);
    el("tactic").textContent = styleNote || (sacrifice ? `!! Sound sacrifice candidate: ${sacrifice.san} invests a ${sacrifice.piece}. Near-best at depth ${sacrifice.depth}.` : mode === "pro" && hunt ? selectedMove ? "No verified sacrifice candidate in the current lines." : "Looking for a sound sacrifice when analysis finishes\u2026" : "");
    el("tactic").title = host.dataset.moveSource === "recorded" ? `Example recorded game: ${host.dataset.recordedGame}` : "";
    el("alternatives").textContent = ["book", "recorded"].includes(host.dataset.moveSource ?? "") ? "Recorded / opening repertoire \xB7 no engine score claimed" : "Strongest engine alternatives";
    el("coach-panel").hidden = !current;
    if (current) {
      const guide = coaching(current, selectedMove, selectedLine?.pv ?? [], studyFocus);
      if (guide.promotion && selectedMove.length === 5) promotionAdvice = { from: selectedMove.slice(0, 2), to: selectedMove.slice(2, 4), color: current.split(" ")[1], message: guide.promotion, fen: current };
      const promotion = guide.promotion || (promotionInProgress ? promotionAdvice?.message : "") || "";
      el("action").textContent = selectedMove ? guide.action : promotionInProgress ? "Choose the promotion piece shown below." : "Waiting for a move recommendation.";
      el("promotion").textContent = promotion;
      el("promotion").hidden = !promotion;
      el("study-note").textContent = guide.focusNote;
      el("material").textContent = guide.material;
      el("continuation").textContent = guide.continuation;
      el("plans").replaceChildren(...guide.plans.map((text) => {
        const item = document.createElement("li");
        item.textContent = text;
        item.style.cssText = "border:0;padding:3px 0;font-size:11px";
        return item;
      }));
    } else {
      el("action").textContent = promotionInProgress ? "Choose the promotion piece shown below." : "";
      el("promotion").textContent = promotionInProgress ? promotionAdvice?.message ?? "" : "";
      el("promotion").hidden = !promotionInProgress;
    }
    const list = el("moves");
    list.replaceChildren();
    const sorted = [...lines.values()].sort((a, b) => a.rank - b.rank);
    for (const line of sorted) {
      const pv2 = legalPV(current, line.pv);
      if (!pv2.length) continue;
      const li = document.createElement("li"), score = document.createElement("span"), small = document.createElement("small");
      if (selectedAltUCI && line.pv[0] === selectedAltUCI) li.classList.add("sel");
      li.textContent = `${line.rank}. ${pv2[0].san}`;
      score.textContent = scoreLabel(line, current.split(" ")[1]);
      small.textContent = pv2.slice(1, 7).map((m) => m.san).join(" ");
      li.append(score, small);
      li.addEventListener("click", () => {
        selectedAltUCI = line.pv[0];
        selectedMove = line.pv[0];
        selectedLine = line;
        source.dataset.square = line.pv[0].slice(0, 2);
        dest.dataset.square = line.pv[0].slice(2, 4);
        playSound("move");
        render();
        draw();
        drawArrow();
      });
      list.append(li);
    }
    // QuickChess v2 UI state sync
    el("btn-sound").textContent = soundEnabled ? "Sound  ✓" : "Sound";
    el("btn-sound").className = soundEnabled ? "on" : "";
    el("btn-arrow").textContent = showArrow ? "Arrow  ✓" : "Arrow";
    el("btn-arrow").className = showArrow ? "on" : "";
    el("btn-automove").textContent = autoMoveEnabled ? "⏸ Auto-Move" : "▶ Auto-Move";
    el("btn-automove").className = autoMoveEnabled ? "on" : "";
    var streamBtn = el("btn-stream");
    if (streamBtn) {
      streamBtn.className = streamProof ? "btn-full on" : "btn-full";
      streamBtn.innerHTML = streamProof ? "Hidden  <span style=\"color:#22c55e;font-weight:400;float:right\">Shift+S</span>" : "Stream Safe  <span style=\"color:#333;font-weight:400;float:right\">Shift+S</span>";
    }
    // color badge in header
    var badge = el("color-badge");
    if (badge) { badge.innerHTML = "playing as <b>" + (flipped ? "Black" : "White") + "</b>"; }
    // move score
    if (el("move-score") && selectedLine) { el("move-score").textContent = scoreLabel(selectedLine, current ? current.split(" ")[1] : "w"); }
    else if (el("move-score")) { el("move-score").textContent = ""; }
  }
  function beginEngineSearch() {
    const c = tracker.chess ?? new Chess(current);
    collector = new MultiPV(Math.min(3, c.moves().length));
    engineFailed = false;
    status = "Analyzing\u2026";
    command({ id: revision, fen: current, depth, mode, pace });
    render();
  }
  function wittyFallback() {
    const book2 = alienBookMove(current);
    if (book2) {
      engineFailed = false;
      selectedMove = book2.move;
      styleNote = `Fallback repertoire \xB7 ${book2.note}`;
      host.dataset.moveSource = "book";
      host.dataset.engine = "opening-book";
      el("backend").textContent = "Alien Gambit \xB7 fallback opening book";
      source.dataset.square = book2.move.slice(0, 2);
      dest.dataset.square = book2.move.slice(2, 4);
      status = "Opening book ready";
      render();
      draw();
      drawArrow();
      playSound("best");
      if (autoMoveEnabled) setTimeout(autoMovePiece, 150 + Math.random() * 400);
      return;
    }
    beginEngineSearch();
  }
  function analyze() {
    cancel();
    if (!current || !allowedPage(location.pathname)) {
      status = "Waiting for verified position";
      render();
      return;
    }
    const c = tracker.chess ?? new Chess(current);
    if (c.isGameOver()) {
      status = c.isCheckmate() ? "Checkmate" : c.isStalemate() ? "Stalemate" : c.isThreefoldRepetition() ? "Draw by repetition" : "Draw / game over";
      render();
      return;
    }
    if (mode === "witty") {
      const requestRevision = revision, fen = current, preferred = alienBookMove(fen)?.move;
      status = "Matching Witty Alien recorded games\u2026";
      el("backend").textContent = "Witty Alien \xB7 local recorded-game lookup";
      render();
      void chrome.runtime.sendMessage({ target: "background", type: "CV_WITTY_MATCH", nonce, fen, preferred }).then((result) => {
        if (revision !== requestRevision || current !== fen || mode !== "witty") return;
        if (result?.error) throw Error(result.error);
        repertoireAvailable = true;
        const match = result?.match, legal = match && legalPV(current, [match.move]);
        if (match && legal.length) {
          engineFailed = false;
          selectedMove = match.move;
          styleNote = `Witty Alien recorded move \xB7 ${legal[0].san} \xB7 ${match.count}/${match.total} matching recorded occurrences`;
          host.dataset.moveSource = "recorded";
          host.dataset.recordedGame = match.gameUrl ?? "";
          host.dataset.engine = "recorded-games";
          el("backend").textContent = `Recorded repertoire \xB7 ${match.games} published games`;
          source.dataset.square = match.move.slice(0, 2);
          dest.dataset.square = match.move.slice(2, 4);
          status = "Recorded move ready";
          render();
          draw();
          drawArrow();
          playSound("best");
          if (autoMoveEnabled) setTimeout(autoMovePiece, 150 + Math.random() * 400);
        } else wittyFallback();
      }).catch(() => {
        if (revision === requestRevision && current === fen && mode === "witty") {
          repertoireAvailable = false;
          wittyFallback();
        }
      });
      return;
    }
    beginEngineSearch();
  }
  function setPosition(fen) {
    if (fen === current) return;
    if (promotionAdvice?.fen !== fen) promotionAdvice = null;
    current = fen;
    cancel();
    status = "Position synchronized";
    if (auto) analyze();
    else render();
  }
  chrome.runtime.onMessage.addListener((data, sender, reply) => {
    if (sender.id !== chrome.runtime.id) return;
    if (data?.type === "CV_STATUS" || data?.type === "CV_RESTORE") {
      if (data.type === "CV_RESTORE") {
        shadow.querySelector("main").hidden = false;
        el("collapse").textContent = "\u25BE";
        dirty = true;
        tick();
      }
      reply({ version: chrome.runtime.getManifest().version, path: location.pathname, permitted: allowedPage(location.pathname), panelVisible: host.isConnected && !host.hidden, boardDetected: !!board, status, boardStatus });
      return;
    }
    if (sender.id !== chrome.runtime.id || data?.nonce !== nonce || data.type !== "CV_ENGINE") return;
    if (mode === "witty" && ["book", "recorded"].includes(host.dataset.moveSource ?? "")) return;
    const e = { data };
    if (e.data.backend) {
      el("backend").textContent = `Stockfish \xB7 ${e.data.backend}`;
      host.dataset.engine = String(e.data.backend);
    }
    if (e.data.restarting) {
      lines.clear();
      selectedMove = "";
      selectedLine = void 0;
      sacrifice = void 0;
      styleNote = "";
      collector = new MultiPV(current ? Math.min(3, new Chess(current).moves().length) : 3);
      source.dataset.square = "";
      dest.dataset.square = "";
      status = "Starting compatibility engine\u2026";
      draw();
      render();
      drawArrow();
    }
    if (e.data.error) {
      cancel();
      engineFailed = true;
      status = String(e.data.error);
      render();
      return;
    }
    if (e.data.id !== revision || !current) return;
    const line = String(e.data.line ?? "");
    const info = parseInfo(line);
    if (info && info.rank <= 3 && !info.bound && legalPV(current, info.pv).length) {
      const complete = collector.push(info);
      if (!complete) return;
      lines = new Map(complete.map((line2) => [line2.rank, line2]));
      render();
    } else if (line.startsWith("bestmove")) {
      const uci = line.split(/\s+/)[1] ?? "";
      host.dataset.engineMove = uci;
      const humanity = mode === "stealth" ? 70 : 0;
      const pick = chooseRecommendation(current, mode, hunt, uci, [...lines.values()], humanity);
      if (pick) {
        selectedMove = pick.move;
        selectedLine = pick.line;
        sacrifice = pick.sacrifice;
        styleNote = pick.note ?? "";
        host.dataset.moveSource = pick.source ?? "engine";
        source.dataset.square = pick.move.slice(0, 2);
        dest.dataset.square = pick.move.slice(2, 4);
        status = "Analysis ready";
        playSound("best");
        drawArrow();
        if (autoMoveEnabled) setTimeout(autoMovePiece, (mode === "stealth" || mode === "alien") ? 800 + Math.random() * 1400 : 150 + Math.random() * 400);
      } else status = "No legal engine line";
      draw();
      render();
      drawArrow();
    }
  });
  window.addEventListener("message", (e) => {
    if (e.data?.nonce !== nonce) return;
    if (e.source === window && e.origin === location.origin && e.data.type === "CV_STATE") {
      bridgeFen = validFen(e.data.fen);
      if (!bridgeFen && typeof e.data.pgn === "string") try {
        const c = new Chess();
        c.loadPgn(e.data.pgn);
        bridgeFen = c.fen();
      } catch {
      }
      dirty = true;
    }
  });
  var resize = new ResizeObserver(draw);
  function tick() {
    const mount = document.fullscreenElement ?? document.documentElement;
    if (host.parentElement !== mount) mount.append(host);
    if (overlay.parentElement !== mount) mount.append(overlay);
    if (arrowCanvas.parentElement !== mount) mount.append(arrowCanvas);
    const permitted = allowedPage(location.pathname);
    host.hidden = !permitted;
    if (lastPath !== location.pathname) {
      lastPath = location.pathname;
      tracker.reset();
      promotionAdvice = null;
      promotionInProgress = false;
      current = "";
      bridgeFen = null;
      candidate = "";
      cancel();
      dirty = true;
    }
    if (!permitted) {
      overlay.style.display = "none";
      arrowCanvas.style.display = "none";
      return;
    }
    if (document.hidden) return;
    qcApplyPrivacy();
    const next = findBoard();
    if (next !== board) {
      resize.disconnect();
      board = next;
      tracker.reset();
      promotionAdvice = null;
      promotionInProgress = false;
      current = "";
      bridgeFen = null;
      candidate = "";
      cancel();
      if (board) resize.observe(board);
      dirty = true;
    }
    if (!board) {
      boardStatus = "No supported board found";
      status = "Waiting";
      render();
      return;
    }
    const now = performance.now();
    if (now - lastRead > 500) {
      lastRead = now;
      window.postMessage({ type: "CV_READ", nonce }, location.origin);
      dirty = true;
    }
    if (!dirty) {
      draw();
      drawArrow();
      return;
    }
    dirty = false;
    prepareVision(board, () => {
      dirty = true;
    });
    const state = readBoard(board);
    flipped = state.flipped;
    draw();
    drawArrow();
    promotionInProgress = promotionWaiting(state.placement, promotionAdvice);
    if (promotionInProgress) {
      if (current || lines.size) {
        current = "";
        cancel();
      }
      boardStatus = "Pawn reached the last rank \xB7 promotion choice pending";
      status = "Choose promotion piece";
      render();
      return;
    }
    const signature = state.placement ?? "";
    if (signature !== candidate) {
      candidate = signature;
      stableSince = now;
      cancel();
      status = "Waiting for board to settle";
      render();
      dirty = true;
      return;
    }
    if (now - stableSince < 220) {
      dirty = true;
      return;
    }
    if (!signature) {
      if (current) {
        current = "";
        cancel();
      }
      boardStatus = "Unreadable or moving pieces";
      status = "Waiting for stable board";
      render();
      return;
    }
    let fen = null;
    if (manualPending && manualPending.split(" ")[0] === signature) {
      tracker.accept(manualPending);
      fen = manualPending;
      manualPending = null;
    } else if (bridgeFen && bridgeFen.split(" ")[0] === signature) {
      const tracked = tracker.sync(signature);
      if (tracked === bridgeFen) fen = tracked;
      else if (tracker.accept(bridgeFen)) fen = bridgeFen;
    } else fen = tracker.sync(signature);
    boardStatus = `Board detected \xB7 ${flipped ? "Black" : "White"} at bottom \xB7 ${bridgeFen ? "game data" : "legal DOM tracking"}`;
    if (!fen) {
      if (current) {
        current = "";
        cancel();
      }
      status = "Position uncertain \u2014 supply full FEN";
      render();
      return;
    }
    const changed = fen !== current;
    setPosition(fen);
    if (!changed && status === "Waiting for board to settle" && !engineFailed) {
      if (auto) analyze();
      else {
        status = "Position synchronized";
        render();
      }
    }
    render();
  }
  var observer = new MutationObserver((records) => {
    if (records.some((r) => !host.contains(r.target) && !overlay.contains(r.target) && !arrowCanvas.contains(r.target))) dirty = true;
  });
  observer.observe(document.documentElement, { subtree: true, childList: true, attributes: true, attributeFilter: ["class", "style", "data-square", "data-piece", "fen", "data-fen", "orientation"] });
  setInterval(tick, 100);
  window.addEventListener("scroll", () => {
    draw();
    drawArrow();
  }, true);
  window.addEventListener("resize", () => {
    draw();
    drawArrow();
  });
  document.addEventListener("visibilitychange", () => {
    if (document.hidden) {
      cancel();
      status = "Paused while tab is hidden";
      render();
    } else {
      dirty = true;
      current = "";
      cancel();
      status = "Resynchronizing";
      render();
    }
  });
  el("depth").addEventListener("change", () => {
    depth = Math.max(1, Math.min(40, Number(el("depth").value) || 16));
    el("depth").value = String(depth);
    save();
    if (auto) analyze();
  });
  el("mode").addEventListener("change", () => {
    mode = modeId(el("mode").value);
    if (mode === "witty") {
      studyFocus = "witty";
      el("study-focus").value = studyFocus;
    }
    save();
    if (auto) analyze();
    else {
      cancel();
      status = "Mode updated";
      render();
    }
  });
  el("pace").addEventListener("change", () => {
    pace = paceId(el("pace").value);
    save();
    if (auto) analyze();
    else {
      cancel();
      status = "Pace updated";
      render();
    }
  });
  el("study-focus").addEventListener("change", () => {
    studyFocus = focusId(el("study-focus").value);
    save();
    render();
  });
  el("hunt").addEventListener("change", () => {
    hunt = el("hunt").checked;
    save();
    if (auto) analyze();
    else {
      cancel();
      render();
    }
  });
  el("auto").addEventListener("change", () => {
    auto = el("auto").checked;
    save();
    if (auto) analyze();
    else {
      cancel();
      status = "Automatic analysis off";
      render();
    }
  });
  el("overlay").addEventListener("change", () => {
    overlayEnabled = el("overlay").checked;
    save();
    draw();
    drawArrow();
  });
  el("analyze").addEventListener("click", analyze);
  el("btn-analyze2").addEventListener("click", analyze);
  el("collapse").addEventListener("click", () => {
    const main = shadow.querySelector("main");
    main.hidden = !main.hidden;
    el("collapse").textContent = main.hidden ? "+" : "\u25BE";
  });
  el("load").addEventListener("click", () => {
    const fen = validFen(el("fen").value.trim());
    if (!fen) {
      el("error").textContent = "Invalid FEN or impossible check state.";
      return;
    }
    if (!board || readBoard(board).placement !== fen.split(" ")[0]) {
      el("error").textContent = "FEN pieces do not match the visible board.";
      return;
    }
    el("error").textContent = "";
    manualPending = fen;
    current = "";
    candidate = "";
    dirty = true;
  });
  el("btn-sound").addEventListener("click", () => {
    soundEnabled = !soundEnabled;
    save();
    render();
  });
  el("btn-arrow").addEventListener("click", () => {
    showArrow = !showArrow;
    save();
    drawArrow();
    render();
  });
  el("btn-automove").addEventListener("click", () => {
    autoMoveEnabled = !autoMoveEnabled;
    save();
    render();
    if (autoMoveEnabled && selectedMove) setTimeout(autoMovePiece, (mode === "stealth" || mode === "alien") ? 800 + Math.random() * 1400 : 150 + Math.random() * 400);
  });
  function setStreamProof(on) {
    streamProof = on;
    // visibility:hidden keeps layout intact; display:none causes flicker on restore
    var vis = on ? "hidden" : "visible";
    host.style.visibility = vis;
    overlay.style.visibility = vis;
    arrowCanvas.style.visibility = vis;
    save();
    render();
  }
  el("btn-stream").addEventListener("click", () => {
    setStreamProof(!streamProof);
  });
  function save() {
    chrome.storage.local.set({ auto, overlayEnabled, depth, mode, hunt, pace, studyFocus, soundEnabled, autoMoveEnabled, showArrow, streamProof });
  }
  // load privacy settings on startup
  try {
    if (chrome.runtime?.id) {
      chrome.storage.local.get([
        'qc-my-username','qc-select-mine','qc-custom-mine',
        'qc-spoof-name','qc-title-select','qc-select-opp'
      ], function(d) {
        if (!d) return;
        if (shadow.getElementById('qc-my-username') && d['qc-my-username']) shadow.getElementById('qc-my-username').value = d['qc-my-username'];
        if (shadow.getElementById('qc-select-mine') && d['qc-select-mine']) shadow.getElementById('qc-select-mine').value = d['qc-select-mine'];
        if (shadow.getElementById('qc-custom-mine') && d['qc-custom-mine']) shadow.getElementById('qc-custom-mine').value = d['qc-custom-mine'];
        if (shadow.getElementById('qc-spoof-name')  && d['qc-spoof-name'])  shadow.getElementById('qc-spoof-name').value  = d['qc-spoof-name'];
        if (shadow.getElementById('qc-title-select')&& d['qc-title-select'])shadow.getElementById('qc-title-select').value= d['qc-title-select'];
        if (shadow.getElementById('qc-select-opp')  && d['qc-select-opp'])  shadow.getElementById('qc-select-opp').value  = d['qc-select-opp'];
        if (shadow.getElementById('qc-spoof-elo')    && d['qc-spoof-elo'])    shadow.getElementById('qc-spoof-elo').value    = d['qc-spoof-elo'];
        var wrap = shadow.getElementById('qc-custom-mine-wrap');
        var ms = shadow.getElementById('qc-select-mine');
        if (wrap && ms) wrap.style.display = ms.value === 'replace' ? 'flex' : 'none';
      });
    }
  } catch(e) {}
  // wire privacy listeners
  ['qc-select-mine','qc-select-opp','qc-title-select'].forEach(function(id) {
    var el3 = shadow.getElementById(id); if (el3) el3.addEventListener('change', qcSavePrivacy);
  });
  ['qc-my-username','qc-custom-mine','qc-spoof-name','qc-spoof-elo'].forEach(function(id) {
    var el3 = shadow.getElementById(id); if (el3) el3.addEventListener('input', qcSavePrivacy);
  });

  chrome.storage.local.get(["auto", "overlayEnabled", "depth", "mode", "hunt", "pace", "studyFocus", "soundEnabled", "autoMoveEnabled", "showArrow", "streamProof"]).then((s) => {
    auto = s.auto !== false;
    overlayEnabled = s.overlayEnabled !== false;
    depth = Math.max(1, Math.min(40, Number(s.depth) || 16));
    mode = modeId(s.mode);
    hunt = s.hunt !== false;
    pace = paceId(s.pace);
    studyFocus = focusId(s.studyFocus);
    soundEnabled = s.soundEnabled !== false;
    autoMoveEnabled = !!s.autoMoveEnabled;
    showArrow = s.showArrow !== false;
    // restore stream-proof state across page loads
    if (s.streamProof) setStreamProof(true);
    el("pace").value = pace;
    el("study-focus").value = studyFocus;
    el("mode").value = mode;
    el("hunt").checked = hunt;
    el("auto").checked = auto;
    el("overlay").checked = overlayEnabled;
    el("depth").value = String(depth);
    dirty = true;
    render();
  });
  window.addEventListener("keydown", (e) => {
    if (e.target && e.target.tagName === "INPUT") return;
    if (e.key === "a" || e.key === "A") {
      analyze();
      e.preventDefault();
    }
    if (e.key === "S") {
      // Shift+S toggles stream-proof mode (lowercase s is chess.com board sound)
      setStreamProof(!streamProof);
      e.preventDefault();
    }
    if (e.key === " ") {
      auto = !auto;
      el("auto").checked = auto;
      save();
      if (auto) analyze();
      e.preventDefault();
    }
  });
  tick();
})();
/*! Bundled license information:

chess.js/dist/esm/chess.js:
  (**
   * @license
   * Copyright (c) 2025, Jeff Hlywa (jhlywa@gmail.com)
   * All rights reserved.
   *
   * Redistribution and use in source and binary forms, with or without
   * modification, are permitted provided that the following conditions are met:
   *
   * 1. Redistributions of source code must retain the above copyright notice,
   *    this list of conditions and the following disclaimer.
   * 2. Redistributions in binary form must reproduce the above copyright notice,
   *    this list of conditions and the following disclaimer in the documentation
   *    and/or other materials provided with the distribution.
   *
   * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
   * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
   * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
   * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE
   * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
   * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
   * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
   * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
   * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
   * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
   * POSSIBILITY OF SUCH DAMAGE.
   *)
*/
//# sourceMappingURL=content.js.map
