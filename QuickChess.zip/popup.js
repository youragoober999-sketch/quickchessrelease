(() => {
  // src/popup.ts
  var status = document.getElementById("status");
  var detail = document.getElementById("detail");
  var restore = document.getElementById("restore");
  document.getElementById("version").textContent = `Chess Vision v${chrome.runtime.getManifest().version}`;
  async function refresh(show = false) {
    try {
      const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
      if (tab?.id === void 0) throw Error("No active tab");
      const result = await chrome.tabs.sendMessage(tab.id, { type: show ? "CV_RESTORE" : "CV_STATUS" });
      if (!result) throw Error("No content script response");
      status.textContent = result.permitted ? result.status : "No supported game page";
      detail.textContent = `${result.path}
${result.boardStatus}
Panel: ${result.panelVisible ? "visible" : "hidden"} \xB7 content v${result.version}`;
      restore.hidden = !result.permitted;
    } catch {
      status.textContent = "Not connected to this page";
      detail.textContent = "On chess.com, refresh the game tab after updating the extension. This popup does not navigate you anywhere.";
      restore.hidden = true;
    }
  }
  restore.addEventListener("click", () => void refresh(true));
  void refresh();
})();
//# sourceMappingURL=popup.js.map
